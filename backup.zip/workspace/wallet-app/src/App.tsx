import { useState, useCallback } from 'react';
import { AuthProvider } from './contexts/AuthContext';
import WalletPage from './pages/WalletPage';
import PlanetTradingPage from './pages/PlanetTradingPage';
import ChatPage from './pages/ChatPage';
import DoubaoCallPage from './pages/DoubaoCallPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DeepSeekPlanetPage from './pages/DeepSeekPlanetPage';
import PlanetPage from './pages/PlanetPage';
import Layout from './layouts/Layout';

function App() {
  const [currentPage, setCurrentPage] = useState<'wallet' | 'planet' | 'chat' | 'doubao' | 'login' | 'register' | 'deepseek' | 'knowledge'>('login');
  const [activeTab, setActiveTab] = useState<'chat' | 'planet'>('chat');

  // 事件处理函数稳定性：若 onTabChange 是内联函数，可通过 useCallback 缓存，减少子组件因 props 变化重渲染
  const handleTabChange = useCallback((tab: 'chat' | 'planet') => {
    setActiveTab(tab);
    if (tab === 'chat') {
      setCurrentPage('chat');
    } else {
      setCurrentPage('planet');
    }
  }, []);

  return (
    <AuthProvider>
      <Layout activeTab={activeTab} onTabChange={handleTabChange}>
        {currentPage === 'wallet' ? (
          <WalletPage />
        ) : currentPage === 'planet' ? (
          <PlanetPage />
        ) : currentPage === 'doubao' ? (
          <DoubaoCallPage />
        ) : currentPage === 'chat' ? (
          <ChatPage />
        ) : currentPage === 'register' ? (
          <RegisterPage />
        ) : currentPage === 'deepseek' ? (
          <DeepSeekPlanetPage />
        ) : currentPage === 'knowledge' ? (
          <PlanetTradingPage />
        ) : (
          <LoginPage />
        )}
      </Layout>
    </AuthProvider>
  );
}

export default App;
