import React from 'react';
import TabNavigation from '../components/TabNavigation';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: 'chat' | 'planet';
  onTabChange: (tab: 'chat' | 'planet') => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange }) => {
  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* 页面内容 */}
      <div className="flex-1">
        {children}
      </div>
      
      {/* 底部导航 - 持久显示 */}
      <div className="fixed bottom-5 left-1/2 transform -translate-x-1/2 z-10">
        <TabNavigation 
          activeTab={activeTab} 
          onTabChange={onTabChange} 
        />
      </div>
    </div>
  );
};

export default Layout;
