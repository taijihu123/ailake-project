import { useAuth } from '../contexts/AuthContext';

const ChatPage = ({ setCurrentPage }: { setCurrentPage: (page: 'wallet' | 'planet' | 'chat' | 'doubao' | 'login') => void }) => {
  const { user, logout } = useAuth();
  return (
    <div className="min-h-screen bg-white pb-20">
      <div className="max-w-md mx-auto">
        {/* 顶部栏 */}
        <div className="top-bar">
          <div className="top-left">
            <img 
              src="/leaf-icon.png" 
              alt="Leaf Logo" 
              className="top-logo" 
            />
            <span className="top-title">Ailake</span>
          </div>
          {user ? (
            <div className="flex items-center">
              <span className="text-gray-700 mr-2 text-sm">{user.name}</span>
              <img 
                src={user.avatar || "/user-avatar.png"} 
                alt="User Avatar" 
                className="top-avatar" 
              />
              <button 
                onClick={() => {
                  logout();
                  setCurrentPage('login');
                }}
                className="ml-2 text-xs text-gray-500 hover:text-green-600"
              >
                登出
              </button>
            </div>
          ) : (
            <img 
              src="/user-avatar.png" 
              alt="User Avatar" 
              className="top-avatar" 
            />
          )}
        </div>

        {/* 中间大图区域 */}
        <div className="middle">
          <img 
            src="/logo-big.png" 
            alt="装饰绿叶" 
            className="new-middle-leaf" 
          />
        </div>

        {/* 豆包通话按钮 */}
        <div className="px-4 mt-8">
          <button
            onClick={() => setCurrentPage('doubao')}
            className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-3 rounded-2xl font-medium shadow-lg hover:from-green-600 hover:to-green-700 transition-all duration-200 flex items-center justify-center"
          >
            <span className="mr-2">🤖</span>
            启动豆包AI通话
          </button>
          <p className="text-center text-sm text-gray-500 mt-3">
            点击与豆包AI进行实时语音通话
          </p>
        </div>


      </div>
    </div>
  );
};

export default ChatPage;