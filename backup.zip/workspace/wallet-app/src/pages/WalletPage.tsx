import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import ArrowLeftIcon from '@/icons/ArrowLeftIcon';
import ListIcon from '@/icons/ListIcon';
import RechargeIcon from '@/icons/RechargeIcon';
import WithdrawIcon from '@/icons/WithdrawIcon';
import TransferIcon from '@/icons/TransferIcon';
import HistoryIcon from '@/icons/HistoryIcon';

const WalletPage = () => {
  // 交易功能数据
  const tradingFunctions = [
    { id: 1, name: 'Recharge', icon: <RechargeIcon /> },
    { id: 2, name: 'Withdraw', icon: <WithdrawIcon /> },
    { id: 3, name: 'Transfer', icon: <TransferIcon /> },
    { id: 4, name: 'History', icon: <HistoryIcon /> },
  ];

  // 交易记录数据
  const transactions = [
    { id: 1, type: 'AI Coin Purchase', amount: '-1,000.00 AIC', time: '2024-09-03 10:30', isPositive: false },
    { id: 2, type: 'Content Creation Reward', amount: '+50.00 AIC', time: '2024-09-03 09:15', isPositive: true },
    { id: 3, type: 'Knowledge Q&A Reward', amount: '+30.00 AIC', time: '2024-09-02 16:45', isPositive: true },
  ];

  // 处理交易功能点击事件
  const handleTradingFunctionClick = (functionName: string) => {
    console.log(`点击了${functionName}功能`);
    // 这里可以添加具体的业务逻辑
    alert(`点击了${functionName}功能`);
  };

  // 处理交易记录点击事件
  const handleTransactionClick = (transactionType: string) => {
    console.log(`点击了交易记录: ${transactionType}`);
    // 这里可以添加具体的业务逻辑
    alert(`查看交易详情: ${transactionType}`);
  };



  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="max-w-md mx-auto">
        {/* 顶部栏 */}
        <div className="top-bar">
          <div className="top-left">
            <img 
              src="/leaf-icon.png" 
              alt="Leaf Logo" 
              className="top-logo" 
            />
            <span className="top-title">AiLake</span>
          </div>
          <img 
            src="/user-avatar.png" 
            alt="User Avatar" 
            className="top-avatar" 
          />
        </div>

        {/* 中间区域容器 */}
        <div className="px-4 space-y-6 mt-4 content">
          {/* Trading 模块 */}
          <Card className="rounded-2xl shadow-sm">
            <CardHeader className="flex flex-row items-center space-x-2 pb-4">
              <ArrowLeftIcon />
              <CardTitle className="text-lg font-semibold">Trading</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                {tradingFunctions.map((func) => (
                  <Card 
                    key={func.id} 
                    className="text-center p-4 cursor-pointer hover:bg-gray-50 rounded-xl border-0 shadow-sm transition-all duration-200 hover:shadow-md active:scale-95"
                    onClick={() => handleTradingFunctionClick(func.name)}
                  >
                    <div className="flex justify-center mb-2 text-green-600">
                      {func.icon}
                    </div>
                    <div className="font-medium text-gray-700">{func.name}</div>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 交易记录模块 */}
          <Card className="rounded-2xl shadow-sm">
            <CardHeader className="flex flex-row items-center space-x-2 pb-4">
              <ListIcon />
              <CardTitle className="text-lg font-semibold">Latest Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {transactions.map((transaction) => (
                  <div 
                    key={transaction.id} 
                    className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0 cursor-pointer hover:bg-gray-50 px-2 rounded-lg transition-colors duration-200 active:scale-98"
                    onClick={() => handleTransactionClick(transaction.type)}
                  >
                    <div>
                      <div className="font-medium text-gray-800">{transaction.type}</div>
                      <div className="text-sm text-gray-500">{transaction.time}</div>
                    </div>
                    <div className={`font-semibold ${transaction.isPositive ? 'text-green-500' : 'text-red-500'}`}>
                      {transaction.amount}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>


      </div>
    </div>
  );
};

export default WalletPage;