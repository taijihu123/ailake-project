import { useAuth } from '../contexts/AuthContext';

const PlanetPage = ({ setCurrentPage }: { setCurrentPage: (page: 'wallet' | 'planet' | 'chat' | 'doubao' | 'login' | 'register' | 'deepseek' | 'knowledge') => void }) => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* 顶部栏 */}
      <div className="top-bar">
        <div className="top-left">
          <button 
            className="menu-btn bg-transparent border-none text-xl cursor-pointer mr-2"
            onClick={() => setCurrentPage('chat')}
          >
            ☰
          </button>
          <img 
            src="/leaf-icon.png" 
            alt="Leaf Logo" 
            className="top-logo" 
          />
          <span className="top-title">AiLake</span>
        </div>
        <div className="flex items-center">
          {user ? (
            <>
              <span className="text-gray-700 mr-2 text-sm">{user.name}</span>
              <img 
                src={user.avatar || "/user-avatar.png"} 
                alt="User Avatar" 
                className="top-avatar" 
              />
            </>
          ) : (
            <img 
              src="/user-avatar.png" 
              alt="User Avatar" 
              className="top-avatar" 
            />
          )}
          <button 
            onClick={() => setCurrentPage('wallet')}
            className="mx-2 bg-green-500 text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-green-600 transition-colors duration-200"
          >
            💳
          </button>
          <button className="action-btn bg-transparent border-none text-xl cursor-pointer">
            +
          </button>
        </div>
      </div>

      {/* 中间内容区 - 极简风格 */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-center mb-6 text-black">
          欢迎探索知识星球
        </h1>
        
        <p className="text-gray-600 text-center max-w-2xl mb-8 leading-relaxed">
          在这里您可以发现丰富的知识资源，与全球用户共同构建和共享知识。
        </p>
        
        <button
          onClick={() => setCurrentPage('knowledge')}
          className="bg-black text-white py-3 px-6 rounded-2xl font-medium shadow-lg hover:bg-gray-800 transition-all duration-200 flex items-center"
        >
          进入知识库
        </button>
      </div>
    </div>
  );
};

export default PlanetPage;
