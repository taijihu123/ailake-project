import { createContext, useState, useEffect, useContext, ReactNode } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  generateAvatar: () => string;
  loginWithWeChat: () => Promise<boolean>;
  loginWithTikTok: () => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  // 检查本地存储中的用户信息
  useEffect(() => {
    const storedUser = localStorage.getItem('ailake_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  // 登录函数
  const login = async (email: string, password: string): Promise<boolean> => {
    // 模拟API调用
    return new Promise((resolve) => {
      setTimeout(() => {
        // 简单的验证逻辑（实际应用中应该调用真实API）
        if (email && password) {
          const userData: User = {
            id: '1',
            name: '用户' + email.split('@')[0],
            email,
            avatar: generateAvatar()
          };
          setUser(userData);
          localStorage.setItem('ailake_user', JSON.stringify(userData));
          resolve(true);
        } else {
          resolve(false);
        }
      }, 1000);
    });
  };

  // 注册函数
  const register = async (name: string, email: string, password: string): Promise<boolean> => {
    // 模拟API调用
    return new Promise((resolve) => {
      setTimeout(() => {
        // 简单的注册逻辑（实际应用中应该调用真实API）
        if (name && email && password) {
          const userData: User = {
            id: Date.now().toString(),
            name,
            email,
            avatar: generateAvatar()
          };
          setUser(userData);
          localStorage.setItem('ailake_user', JSON.stringify(userData));
          resolve(true);
        } else {
          resolve(false);
        }
      }, 1000);
    });
  };

  // 登出函数
  const logout = () => {
    setUser(null);
    localStorage.removeItem('ailake_user');
  };

  // 生成AI头像的函数
  const generateAvatar = (): string => {
    // 生成随机头像URL（实际应用中可以调用AI头像生成API）
    const colors = ['6366f1', '8b5cf6', 'ec4899', '10b981', 'f59e0b', 'ef4444'];
    const color = colors[Math.floor(Math.random() * colors.length)];
    const initials = user ? user.name.substring(0, 2).toUpperCase() : 'AI';
    return `https://ui-avatars.com/api/?name=${initials}&background=${color}&color=fff`;
  };

  // 微信登录函数
  const loginWithWeChat = async (): Promise<boolean> => {
    // 模拟微信登录流程（实际应用中需要接入微信SDK）
    return new Promise((resolve) => {
      setTimeout(() => {
        const userData: User = {
          id: 'wechat_' + Date.now().toString(),
          name: '微信用户',
          email: 'wechat_' + Date.now() + '@ailake.com',
          avatar: generateAvatar()
        };
        setUser(userData);
        localStorage.setItem('ailake_user', JSON.stringify(userData));
        resolve(true);
      }, 1500);
    });
  };

  // 抖音登录函数
  const loginWithTikTok = async (): Promise<boolean> => {
    // 模拟抖音登录流程（实际应用中需要接入抖音SDK）
    return new Promise((resolve) => {
      setTimeout(() => {
        const userData: User = {
          id: 'tiktok_' + Date.now().toString(),
          name: '抖音用户',
          email: 'tiktok_' + Date.now() + '@ailake.com',
          avatar: generateAvatar()
        };
        setUser(userData);
        localStorage.setItem('ailake_user', JSON.stringify(userData));
        resolve(true);
      }, 1500);
    });
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, generateAvatar, loginWithWeChat, loginWithTikTok }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};