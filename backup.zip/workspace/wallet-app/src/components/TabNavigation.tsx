import React from 'react';
import styled from 'styled-components';

interface TabNavigationProps {
  activeTab: 'chat' | 'planet';
  onTabChange: (tab: 'chat' | 'planet') => void;
}

// 最外层的胶囊容器
const Container = styled.div`
  display: flex;          /* 让内部元素水平排列 */
  align-items: center;    /* 垂直居中 */
  height: 60px;           /* 容器高度 */
  padding: 0 16px;        /* 左右内边距，避免内容贴边 */
  background-color: #fff; /* 容器背景色 */
  border-radius: 30px;    /* 胶囊圆角（高度的一半） */
  box-shadow: 0 2px 8px rgba(0,0,0,0.1); /* 添加阴影增强层次 */
`;

// 内部左侧的圆形按钮
const CircleButton = styled.div<{ isActive: boolean }>`
  width: 60px;            /* 圆形直径，与容器高度一致更协调 */
  height: 60px;
  border-radius: 50%;     /* 圆形 */
  background-color: ${props => props.isActive ? '#2D7D46' : '#f5f5f5'};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${props => props.isActive ? '#fff' : '#333'};
  font-size: 16px;
  cursor: pointer;
`;

// 内部右侧的文字区域
const Text = styled.div<{ isActive: boolean }>`
  margin-left: 24px;      /* 与圆形按钮的间距 */
  font-size: 16px;
  color: ${props => props.isActive ? '#2D7D46' : '#333'};
  cursor: pointer;
`;

const TabNavigation: React.FC<TabNavigationProps> = ({ activeTab, onTabChange }) => {
  return (
    <Container>
      <CircleButton 
        isActive={activeTab === 'chat'} 
        onClick={() => onTabChange('chat')}
      >
        对话
      </CircleButton>
      <Text 
        isActive={activeTab === 'planet'} 
        onClick={() => onTabChange('planet')}
      >
        星球
      </Text>
    </Container>
  );
};

export default React.memo(TabNavigation);
