import React from 'react';
import styled from 'styled-components';

interface TabNavigationProps {
  activeTab: 'chat' | 'planet';
  onTabChange: (tab: 'chat' | 'planet') => void;
}

// 胶囊容器：增加渐变阴影，提升质感
const Container = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 260px;
  height: 64px;
  background-color: #ffffff;
  border-radius: 32px;
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08), 0 3px 6px rgba(0, 0, 0, 0.12);
  position: relative;
  overflow: hidden;
`;

// 标签按钮： hover 效果 + 更细腻的文字样式
const TabBtn = styled.div<{ isActive: boolean }>`
  flex: 1;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 17px;
  font-weight: 500;
  cursor: pointer;
  z-index: 1;
  color: ${props => props.isActive ? '#ffffff' : '#666666'};
  transition: color 0.2s ease-in-out;

  &:hover {
    opacity: 0.9;
  }
`;

// 选中态指示器：增加微渐变，更具层次感
const ActiveIndicator = styled.div<{ activeTab: 'chat' | 'planet' }>`
  position: absolute;
  left: ${props => props.activeTab === 'chat' ? '12px' : 'calc(100% - 62px)'};
  top: 12px;
  width: 40px;
  height: 40px;
  background: linear-gradient(135deg, #2D7D46 0%, #34A853 100%);
  border-radius: 50%;
  box-shadow: 0 4px 8px rgba(45, 125, 70, 0.3);
  transition: left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
`;

const TabNavigation: React.FC<TabNavigationProps> = ({ activeTab, onTabChange }) => {
  return (
    <Container>
      <ActiveIndicator activeTab={activeTab} />
      <TabBtn isActive={activeTab === 'chat'} onClick={() => onTabChange('chat')}>
        对话
      </TabBtn>
      <TabBtn isActive={activeTab === 'planet'} onClick={() => onTabChange('planet')}>
        星球
      </TabBtn>
    </Container>
  );
};

// React.memo 缓存组件：用 React.memo 包裹组件，避免父组件重渲染时，胶囊组件无变化却重复渲染
export default React.memo(TabNavigation);