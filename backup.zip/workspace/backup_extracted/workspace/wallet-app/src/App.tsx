import { useState, useCallback } from 'react';
import { AuthProvider } from './contexts/AuthContext';
import WalletPage from './pages/WalletPage';
import PlanetTradingPage from './pages/PlanetTradingPage';
import ChatPage from './pages/ChatPage';
import DoubaoCallPage from './pages/DoubaoCallPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DeepSeekPlanetPage from './pages/DeepSeekPlanetPage';
import PlanetPage from './pages/PlanetPage';
import TabNavigation from './components/TabNavigation';

function App() {
  const [currentPage, setCurrentPage] = useState<'wallet' | 'planet' | 'chat' | 'doubao' | 'login' | 'register' | 'deepseek' | 'knowledge'>('login');

  // 事件处理函数稳定性：若 onTabChange 是内联函数，可通过 useCallback 缓存，减少子组件因 props 变化重渲染
  const handleTabChange = useCallback((tab: 'chat' | 'planet') => {
    if (tab === 'chat') {
      setCurrentPage('chat');
    } else {
      setCurrentPage('planet');
    }
  }, []);

  return (
    <AuthProvider>
      <div>
        {currentPage === 'wallet' ? (
          <WalletPage />
        ) : currentPage === 'planet' ? (
          <PlanetPage setCurrentPage={setCurrentPage} />
        ) : currentPage === 'doubao' ? (
          <DoubaoCallPage setCurrentPage={setCurrentPage} />
        ) : currentPage === 'chat' ? (
          <ChatPage setCurrentPage={setCurrentPage} />
        ) : currentPage === 'register' ? (
          <RegisterPage setCurrentPage={setCurrentPage} />
        ) : currentPage === 'deepseek' ? (
          <DeepSeekPlanetPage setCurrentPage={setCurrentPage} />
        ) : currentPage === 'knowledge' ? (
          <PlanetTradingPage setCurrentPage={setCurrentPage} />
        ) : (
          <LoginPage setCurrentPage={setCurrentPage} />
        )}
        
        {/* 在聊天页面、星球页面或交易页面显示胶囊式导航 */}
        {(currentPage === 'chat' || currentPage === 'planet' || currentPage === 'knowledge') && (
          <div style={{ 
            position: 'fixed', 
            bottom: '20px', 
            left: '50%', 
            transform: 'translateX(-50%)',
            zIndex: 1000
          }}>
            <TabNavigation 
              activeTab={currentPage === 'chat' ? 'chat' : 'planet'} 
              onTabChange={handleTabChange} 
            />
          </div>
        )}
      </div>
    </AuthProvider>
  );
}

export default App;
