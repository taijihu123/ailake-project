import { useState } from 'react';

const DeepSeekPlanetPage = ({ setCurrentPage }: { setCurrentPage: (page: 'wallet' | 'planet' | 'chat' | 'doubao' | 'login' | 'register' | 'deepseek' | 'knowledge') => void }) => {
  const [inputText, setInputText] = useState('');
  const [messages, setMessages] = useState([
    { id: 1, text: '嗨～欢迎来到星球', isUser: false },
    { id: 2, text: '这里可以探索、交流，像DeepSeek一样开启智能互动～', isUser: false }
  ]);

  const handleSend = () => {
    if (inputText.trim() !== '') {
      // 添加用户消息
      const newUserMessage = {
        id: messages.length + 1,
        text: inputText,
        isUser: true
      };
      
      setMessages([...messages, newUserMessage]);
      setInputText('');
      
      // 模拟AI回复
      setTimeout(() => {
        const aiResponse = {
          id: messages.length + 2,
          text: `我收到了您的消息: "${inputText}"。这是一个模拟回复，实际应用中会连接到AI服务。`,
          isUser: false
        };
        setMessages(prev => [...prev, aiResponse]);
      }, 1000);
    }
  };

  const handleFeatureClick = (featureName: string) => {
    const newMessage = {
      id: messages.length + 1,
      text: `您点击了"${featureName}"功能。这是一个模拟响应。`,
      isUser: false
    };
    setMessages([...messages, newMessage]);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <div className="planet-page min-h-screen bg-white flex flex-col">
      {/* 顶部栏：类似DeepSeek的标题+操作按钮 */}
      <header className="planet-header flex items-center px-6 py-4 border-b border-gray-200">
        <button 
          className="menu-btn bg-transparent border-none text-xl cursor-pointer"
          onClick={() => setCurrentPage('wallet')}
        >
          ←
        </button>
        <h1 className="page-title flex-1 text-center text-lg font-semibold">星球</h1>
        <button className="action-btn bg-transparent border-none text-xl cursor-pointer">
          +
        </button>
      </header>

      {/* 中间内容区：DeepSeek风格的欢迎/功能区 */}
      <main className="planet-content flex-1 flex flex-col items-center justify-center px-6 py-8 overflow-y-auto">
        {messages.length === 2 ? (
          // 初始欢迎界面
          <div className="brand-area text-center mb-8">
            <div className="planet-icon w-20 h-20 rounded-full bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">🌎</span>
            </div>
            <h2 className="greeting text-2xl font-semibold mb-2">嗨～欢迎来到星球</h2>
            <p className="desc text-gray-600 text-center mb-8">这里可以探索、交流，像DeepSeek一样开启智能互动～</p>
            
            {/* 功能模块：类似DeepSeek的卡片/按钮布局 */}
            <div className="features grid grid-cols-3 gap-4 w-full max-w-md">
              <div 
                className="feature-card p-4 bg-gray-100 rounded-lg text-center cursor-pointer transition-all duration-200 hover:bg-gray-200"
                onClick={() => handleFeatureClick('资源探索')}
              >
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-2">
                  <span className="text-blue-500">🔍</span>
                </div>
                <span className="text-sm">资源探索</span>
              </div>
              <div 
                className="feature-card p-4 bg-gray-100 rounded-lg text-center cursor-pointer transition-all duration-200 hover:bg-gray-200"
                onClick={() => handleFeatureClick('社区交流')}
              >
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-2">
                  <span className="text-green-500">💬</span>
                </div>
                <span className="text-sm">社区交流</span>
              </div>
              <div 
                className="feature-card p-4 bg-gray-100 rounded-lg text-center cursor-pointer transition-all duration-200 hover:bg-gray-200"
                onClick={() => handleFeatureClick('智能推荐')}
              >
                <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-2">
                  <span className="text-purple-500">🤖</span>
                </div>
                <span className="text-sm">智能推荐</span>
              </div>
            </div>
          </div>
        ) : (
          // 消息对话界面
          <div className="w-full max-w-2xl flex flex-col h-full">
            <div className="flex-1 overflow-y-auto mb-4 space-y-4">
              {messages.map((message) => (
                <div 
                  key={message.id} 
                  className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
                >
                  <div 
                    className={`max-w-xs md:max-w-md px-4 py-3 rounded-2xl ${
                      message.isUser 
                        ? 'bg-green-500 text-white rounded-br-none' 
                        : 'bg-gray-100 text-gray-800 rounded-bl-none'
                    }`}
                  >
                    {message.text}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* 底部交互区：类似DeepSeek的输入/功能按钮 */}
      <footer className="planet-footer flex items-center p-4 border-t border-gray-200">
        <input 
          type="text" 
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="输入内容..." 
          className="input-field flex-1 px-4 py-3 border border-gray-300 rounded-full outline-none focus:ring-2 focus:ring-green-500"
        />
        <button 
          onClick={handleSend}
          className="send-btn px-5 py-3 bg-green-500 text-white border-none rounded-full cursor-pointer ml-2 hover:bg-green-600 transition-colors duration-200"
        >
          发送
        </button>
        <div className="action-buttons flex gap-2 ml-2">
          <button className="func-btn w-10 h-10 bg-gray-200 border-none rounded-full cursor-pointer hover:bg-gray-300 transition-colors duration-200">
            📎
          </button>
          <button className="func-btn w-10 h-10 bg-gray-200 border-none rounded-full cursor-pointer hover:bg-gray-300 transition-colors duration-200">
            😊
          </button>
        </div>
      </footer>
      
      {/* 知识库页面入口 */}
      <div className="px-6 py-4">
        <button
          onClick={() => setCurrentPage('knowledge')}
          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-2xl font-medium shadow-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 flex items-center justify-center"
        >
          <span className="mr-2">📚</span>
          前往知识库页面
        </button>
      </div>
    </div>
  );
};

export default DeepSeekPlanetPage;