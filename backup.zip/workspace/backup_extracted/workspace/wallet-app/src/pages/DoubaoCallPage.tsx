import { useState, useRef } from 'react';

const DoubaoCallPage = ({ setCurrentPage }: { setCurrentPage: (page: 'wallet' | 'planet' | 'chat' | 'doubao' | 'login') => void }) => {
  const [isCalling, setIsCalling] = useState(false);
  const [callStatus, setCallStatus] = useState('准备连接...');
  const [audioStream, setAudioStream] = useState<MediaStream | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  // 模拟连接豆包API
  const connectToDoubao = async () => {
    setIsCalling(true);
    setCallStatus('正在连接豆包AI...');
    
    try {
      // 请求用户音频权限
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setAudioStream(stream);
      
      // 模拟连接过程
      setTimeout(() => {
        setCallStatus('已连接豆包AI，开始通话');
      }, 2000);
    } catch (error) {
      console.error('获取音频权限失败:', error);
      setCallStatus('连接失败，请检查麦克风权限');
      setIsCalling(false);
    }
  };

  // 断开连接
  const disconnectCall = () => {
    if (audioStream) {
      audioStream.getTracks().forEach(track => track.stop());
      setAudioStream(null);
    }
    setIsCalling(false);
    setCallStatus('通话已结束');
  };

  // 切换静音状态
  const toggleMute = () => {
    if (audioStream) {
      audioStream.getAudioTracks().forEach(track => {
        track.enabled = isMuted;
      });
      setIsMuted(!isMuted);
    }
  };

  // 结束通话
  const endCall = () => {
    disconnectCall();
    // 返回对话页面
    setTimeout(() => {
      setCurrentPage('chat');
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white pb-20">
      <div className="max-w-md mx-auto">
        {/* 顶部栏 */}
        <div className="top-bar">
          <div className="top-left">
            <img 
              src="/leaf-icon.png" 
              alt="Leaf Logo" 
              className="top-logo" 
            />
            <span className="top-title">豆包通话</span>
          </div>
          <img 
            src="/user-avatar.png" 
            alt="User Avatar" 
            className="top-avatar" 
          />
        </div>

        {/* 通话界面 */}
        <div className="px-4 mt-4 content flex flex-col items-center justify-center" style={{ height: 'calc(100vh - 160px)' }}>
          {/* 豆包AI头像 */}
          <div className="relative mb-8">
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center shadow-lg">
              <span className="text-4xl">🤖</span>
            </div>
            {isCalling && (
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center animate-pulse">
                <div className="w-3 h-3 bg-white rounded-full"></div>
              </div>
            )}
          </div>

          {/* 状态显示 */}
          <div className="text-center mb-8">
            <p className="text-lg font-medium text-gray-700">{callStatus}</p>
            {isCalling && (
              <p className="text-sm text-gray-500 mt-2">与豆包AI实时通话中...</p>
            )}
          </div>

          {/* 控制按钮 */}
          <div className="flex space-x-6">
            {isCalling ? (
              <>
                <button 
                  onClick={toggleMute}
                  className={`w-16 h-16 rounded-full flex items-center justify-center shadow-lg transition-all duration-200 ${
                    isMuted ? 'bg-yellow-500' : 'bg-gray-200'
                  }`}
                >
                  {isMuted ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                    </svg>
                  )}
                </button>
                <button 
                  onClick={endCall}
                  className="w-16 h-16 rounded-full bg-red-500 flex items-center justify-center shadow-lg hover:bg-red-600 transition-all duration-200"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </>
            ) : (
              <button 
                onClick={connectToDoubao}
                className="w-16 h-16 rounded-full bg-transparent flex items-center justify-center shadow-lg hover:bg-gray-100 transition-all duration-200 border border-gray-300"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
              </button>
            )}
          </div>

          {/* 功能说明 */}
          <div className="mt-8 text-center text-sm text-gray-500">
            <p>豆包AI实时通话功能</p>
            <p className="mt-1">支持语音交互，随时与AI助手对话</p>
          </div>
        </div>


      </div>
      
      {/* 音频元素 */}
      <audio ref={audioRef} autoPlay />
    </div>
  );
};

export default DoubaoCallPage;