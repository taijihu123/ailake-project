import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import ListIcon from '@/icons/ListIcon';
import PlanetIcon from '@/icons/PlanetIcon';
import TabNavigation from '../components/TabNavigation';

// 创建星球相关的图标组件
const PlanetRechargeIcon = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      <circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" strokeWidth={1.5} />
    </svg>
  );
};

const PlanetExchangeIcon = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
      <circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" strokeWidth={1.5} />
    </svg>
  );
};

const PlanetMarketIcon = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
      <circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" strokeWidth={1.5} />
    </svg>
  );
};

const PlanetHistoryIcon = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
      <circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" strokeWidth={1.5} />
    </svg>
  );
};



const PlanetTradingPage = ({ setCurrentPage }: { setCurrentPage: (page: 'wallet' | 'planet' | 'chat' | 'doubao' | 'login' | 'register' | 'deepseek' | 'knowledge') => void }) => {
  // 定义激活的标签（假设为 'chat' 对应"对话"，'planet' 对应"星球"）
  const [activeTab, setActiveTab] = useState<'chat' | 'planet'>('chat');

  // 星球交易功能数据
  const planetTradingFunctions = [
    { id: 1, name: '星球充值', icon: <PlanetRechargeIcon /> },
    { id: 2, name: '星球兑换', icon: <PlanetExchangeIcon /> },
    { id: 3, name: '星球市场', icon: <PlanetMarketIcon /> },
    { id: 4, name: '星球记录', icon: <PlanetHistoryIcon /> },
  ];

  // 星球交易记录数据
  const planetTransactions = [
    { id: 1, type: '购买星球NFT', amount: '-500.00 AIC', time: '2024-09-03 14:20', isPositive: false },
    { id: 2, type: '完成星球任务奖励', amount: '+100.00 AIC', time: '2024-09-03 11:45', isPositive: true },
    { id: 3, type: '星球签到奖励', amount: '+20.00 AIC', time: '2024-09-02 09:30', isPositive: true },
  ];

  // 处理交易功能点击事件
  const handleTradingFunctionClick = (functionName: string) => {
    console.log(`点击了${functionName}功能`);
    alert(`点击了${functionName}功能`);
  };

  // 处理交易记录点击事件
  const handleTransactionClick = (transactionType: string) => {
    console.log(`点击了交易记录: ${transactionType}`);
    alert(`查看交易详情: ${transactionType}`);
  };

  // 处理标签切换
  const handleTabChange = (tab: 'chat' | 'planet') => {
    setActiveTab(tab);
    if (tab === 'chat') {
      setCurrentPage('chat');
    } else {
      setCurrentPage('planet');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="max-w-md mx-auto">
        {/* 顶部栏 */}
        <div className="top-bar">
          <div className="top-left">
            <img 
              src="/leaf-icon.png" 
              alt="Leaf Logo" 
              className="top-logo" 
            />
            <span className="top-title">星球交易</span>
          </div>
          <img 
            src="/user-avatar.png" 
            alt="User Avatar" 
            className="top-avatar" 
          />
        </div>

        {/* 中间区域容器 */}
        <div className="px-4 space-y-6 mt-4 content">
          {/* Trading 模块 */}
          <Card className="rounded-2xl shadow-sm">
            <CardHeader className="flex flex-row items-center space-x-2 pb-4">
              <PlanetIcon />
              <CardTitle className="text-lg font-semibold">星球功能</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                {planetTradingFunctions.map((func) => (
                  <Card 
                    key={func.id} 
                    className="text-center p-4 cursor-pointer hover:bg-gray-50 rounded-xl border-0 shadow-sm transition-all duration-200 hover:shadow-md active:scale-95"
                    onClick={() => handleTradingFunctionClick(func.name)}
                  >
                    <div className="flex justify-center mb-2 text-green-600">
                      {func.icon}
                    </div>
                    <div className="font-medium text-gray-700">{func.name}</div>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 交易记录模块 */}
          <Card className="rounded-2xl shadow-sm">
            <CardHeader className="flex flex-row items-center space-x-2 pb-4">
              <ListIcon />
              <CardTitle className="text-lg font-semibold">星球交易记录</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {planetTransactions.map((transaction) => (
                  <div 
                    key={transaction.id} 
                    className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0 cursor-pointer hover:bg-gray-50 px-2 rounded-lg transition-colors duration-200 active:scale-98"
                    onClick={() => handleTransactionClick(transaction.type)}
                  >
                    <div>
                      <div className="font-medium text-gray-800">{transaction.type}</div>
                      <div className="text-sm text-gray-500">{transaction.time}</div>
                    </div>
                    <div className={`font-semibold ${transaction.isPositive ? 'text-green-500' : 'text-red-500'}`}>
                      {transaction.amount}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 渲染胶囊组件，传递状态和切换回调 */}
        <div style={{ 
          position: 'fixed', 
          bottom: '20px', 
          left: '50%', 
          transform: 'translateX(-50%)',
          zIndex: 1000
        }}>
          <TabNavigation 
            activeTab={activeTab} 
            onTabChange={handleTabChange} 
          />
        </div>
      </div>
    </div>
  );
};

export default PlanetTradingPage;