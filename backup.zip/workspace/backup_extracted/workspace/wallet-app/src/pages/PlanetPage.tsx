import { useAuth } from '../contexts/AuthContext';

const PlanetPage = ({ setCurrentPage }: { setCurrentPage: (page: 'wallet' | 'planet' | 'chat' | 'doubao' | 'login' | 'register' | 'deepseek' | 'knowledge') => void }) => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* 顶部栏 */}
      <div className="top-bar">
        <div className="top-left">
          <button 
            className="menu-btn bg-transparent border-none text-xl cursor-pointer mr-2"
            onClick={() => setCurrentPage('chat')}
          >
            ☰
          </button>
          <img 
            src="/leaf-icon.png" 
            alt="Leaf Logo" 
            className="top-logo" 
          />
          <span className="top-title">AiLake</span>
        </div>
        <div className="flex items-center">
          {user ? (
            <>
              <span className="text-gray-700 mr-2 text-sm">{user.name}</span>
              <img 
                src={user.avatar || "/user-avatar.png"} 
                alt="User Avatar" 
                className="top-avatar" 
              />
            </>
          ) : (
            <img 
              src="/user-avatar.png" 
              alt="User Avatar" 
              className="top-avatar" 
            />
          )}
          <button 
            onClick={() => setCurrentPage('wallet')}
            className="mx-2 bg-green-500 text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-green-600 transition-colors duration-200"
          >
            💳
          </button>
          <button className="action-btn bg-transparent border-none text-xl cursor-pointer">
            +
          </button>
        </div>
      </div>

      {/* 中间内容区 */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-8">
        <h1 className="text-3xl md:text-4xl font-bold text-center mb-6">
          欢迎来到<span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">星球模块</span>
        </h1>
        
        <p className="text-gray-600 text-center max-w-2xl mb-8 leading-relaxed">
          探索AI驱动的知识网络，发现无限可能。
          在这里您可以参与社区交流、获取智能推荐、探索丰富的资源，
          与全球用户共同构建和共享知识。
        </p>
        
        <button
          onClick={() => setCurrentPage('wallet')}
          className="bg-black text-white py-3 px-6 rounded-2xl font-medium shadow-lg hover:bg-gray-800 transition-all duration-200 flex items-center"
        >
          <span className="mr-2">💳</span>
          进入交易页面
        </button>
        
        <div className="grid grid-cols-2 gap-4 mt-8 max-w-md w-full">
          <button
            onClick={() => alert('探索星球资源功能')}
            className="bg-gradient-to-r from-blue-500 to-blue-600 text-white py-3 px-4 rounded-2xl font-medium shadow-lg hover:from-blue-600 hover:to-blue-700 transition-all duration-200 flex flex-col items-center justify-center"
          >
            <span className="text-2xl mb-2">🔍</span>
            <span>资源探索</span>
          </button>
          <button
            onClick={() => alert('加入星球社区功能')}
            className="bg-gradient-to-r from-green-500 to-green-600 text-white py-3 px-4 rounded-2xl font-medium shadow-lg hover:from-green-600 hover:to-green-700 transition-all duration-200 flex flex-col items-center justify-center"
          >
            <span className="text-2xl mb-2">💬</span>
            <span>社区交流</span>
          </button>
          <button
            onClick={() => alert('智能推荐功能')}
            className="bg-gradient-to-r from-purple-500 to-purple-600 text-white py-3 px-4 rounded-2xl font-medium shadow-lg hover:from-purple-600 hover:to-purple-700 transition-all duration-200 flex flex-col items-center justify-center"
          >
            <span className="text-2xl mb-2">🤖</span>
            <span>智能推荐</span>
          </button>
          <button
            onClick={() => alert('个人中心功能')}
            className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white py-3 px-4 rounded-2xl font-medium shadow-lg hover:from-yellow-600 hover:to-yellow-700 transition-all duration-200 flex flex-col items-center justify-center"
          >
            <span className="text-2xl mb-2">👤</span>
            <span>个人中心</span>
          </button>
        </div>
      </div>


    </div>
  );
};

export default PlanetPage;