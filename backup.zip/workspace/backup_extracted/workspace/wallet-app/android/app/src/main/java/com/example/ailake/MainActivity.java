package com.example.ailake;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
