import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      devOptions: {
        enabled: true
      },
      manifest: {
        name: 'AILake',
        short_name: 'AILake',
        description: 'AILake应用',
        theme_color: '#ffffff',
        icons: [
          {
            src: 'logo-big.png',
            sizes: '192x192',
            type: 'image/png'
          },
          {
            src: 'logo-big.png',
            sizes: '512x512',
            type: 'image/png'
          }
        ]
      }
    })
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    host: "0.0.0.0"
  }
})
