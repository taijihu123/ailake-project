
const jwt = require('jsonwebtoken');

const authMiddleware = async (req, res, next) => {
  try {
    // 从请求头获取token
    const authHeader = req.header('Authorization');
    
    // 检查是否有Authorization头
    if (!authHeader) {
      return res.status(401).json({
        success: false,
        error: {
          code: 401,
          message: '访问被拒绝，缺少认证令牌'
        }
      });
    }

    // 检查令牌格式是否正确
    if (!authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        error: {
          code: 401,
          message: '认证令牌格式不正确'
        }
      });
    }

    // 提取令牌
    const token = authHeader.replace('Bearer ', '');

    // 验证令牌
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'ailake_default_secret');
    
    // 将用户信息添加到请求对象中
    req.user = decoded;
    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        error: {
          code: 401,
          message: '无效的认证令牌'
        }
      });
    }
    
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        error: {
          code: 401,
          message: '认证令牌已过期'
        }
      });
    }

    console.error('认证中间件错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};

module.exports = authMiddleware;
