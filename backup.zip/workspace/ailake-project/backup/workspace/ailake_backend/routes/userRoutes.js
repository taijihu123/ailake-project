
const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const authMiddleware = require('../middleware/authMiddleware');

// 用户注册
router.post('/register', userController.register);

// 用户登录
router.post('/login', userController.login);

// 获取用户头像（需要认证）
router.get('/avatar', authMiddleware, userController.getAvatar);

// 更新用户头像（需要认证）
router.post('/avatar/update', authMiddleware, userController.updateAvatar);

module.exports = router;
