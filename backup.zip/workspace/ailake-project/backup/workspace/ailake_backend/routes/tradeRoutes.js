
const express = require('express');
const router = express.Router();
const tradeController = require('../controllers/tradeController');
const authMiddleware = require('../middleware/authMiddleware');

// 获取交易数据
router.get('/data', tradeController.getTradeData);

// 充值（需要认证）
router.post('/recharge', authMiddleware, tradeController.recharge);

// 提现（需要认证）
router.post('/withdraw', authMiddleware, tradeController.withdraw);

// 转账（需要认证）
router.post('/transfer', authMiddleware, tradeController.transfer);

// 获取交易历史（需要认证）
router.get('/history', authMiddleware, tradeController.getTradeHistory);

module.exports = router;
