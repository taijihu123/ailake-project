
const express = require('express');
const router = express.Router();
const chatController = require('../controllers/chatController');
const authMiddleware = require('../middleware/authMiddleware');

// 发送消息（需要认证）
router.post('/send', authMiddleware, chatController.sendMessage);

// 获取对话历史（需要认证）
router.get('/history', authMiddleware, chatController.getChatHistory);

// 清除对话历史（需要认证）
router.delete('/clear', authMiddleware, chatController.clearChatHistory);

module.exports = router;
