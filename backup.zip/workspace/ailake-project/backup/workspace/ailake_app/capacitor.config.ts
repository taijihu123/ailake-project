
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ailake.app',
  appName: 'Ailake App',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
