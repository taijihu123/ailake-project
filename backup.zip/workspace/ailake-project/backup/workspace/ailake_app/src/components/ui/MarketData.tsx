
import React from 'react';

const MarketData: React.FC = () => {
  // 模拟市场数据
  const marketData = {
    price: "¥1.25",
    change: "+5.2%",
    volume: "1.2M",
    turnover: "¥1.5M"
  };

  return (
    <div className="w-full max-w-md bg-white rounded-xl shadow-md p-6 mb-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">交易数据</h3>
      
      {/* 价格和涨跌幅 */}
      <div className="flex justify-between items-center mb-4">
        <div>
          <p className="text-sm text-gray-600">AI Coin价格</p>
          <p className="text-2xl font-bold text-green-600">{marketData.price}</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-600">24H涨跌幅</p>
          <p className="text-xl font-bold text-green-600 flex items-center">
            ↑ {marketData.change}
          </p>
        </div>
      </div>
      
      {/* 交易量和成交额 */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-green-50 p-4 rounded-lg">
          <p className="text-sm text-gray-600">24H交易量</p>
          <p className="font-semibold text-gray-800">{marketData.volume}</p>
        </div>
        <div className="bg-green-50 p-4 rounded-lg">
          <p className="text-sm text-gray-600">24H成交额</p>
          <p className="font-semibold text-gray-800">{marketData.turnover}</p>
        </div>
      </div>
    </div>
  );
};

export default MarketData;
