
import React from 'react';

const UserAvatar: React.FC = () => {
  // 使用从素材中获取的用户头像
  return (
    <div className="w-10 h-10 rounded-full bg-gray-200 border-2 border-white shadow-md overflow-hidden">
      <img 
        src="/src/assets/images/1757584807113.jpeg" 
        alt="User Avatar" 
        className="w-full h-full object-cover"
      />
    </div>
  );
};

export default UserAvatar;
