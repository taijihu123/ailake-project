
import React from 'react';

const TransactionHistory: React.FC = () => {
  // 模拟交易数据
  const transactions = [
    { id: 1, type: 'AI Coin Purchase', amount: '-1,000.00 AIC', time: '2024-09-03 10:30' },
    { id: 2, type: 'Content Creation Reward', amount: '+50.00 AIC', time: '2024-09-02 14:15' },
    { id: 3, type: 'Knowledge Q&A Reward', amount: '+30.00 AIC', time: '2024-09-01 16:45' },
  ];

  return (
    <div className="w-full max-w-md bg-white rounded-xl shadow-md p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Latest Transactions</h3>
      <div className="space-y-3">
        {transactions.map((transaction) => (
          <div key={transaction.id} className="flex justify-between items-center py-2 border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 cursor-pointer">
            <div>
              <p className="font-medium text-gray-800">{transaction.type}</p>
            </div>
            <div className="text-right">
              <p className={`font-medium ${transaction.amount.startsWith('-') ? 'text-red-600' : 'text-green-600'}`}>
                {transaction.amount}
              </p>
              <p className="text-xs text-gray-500">{transaction.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TransactionHistory;
