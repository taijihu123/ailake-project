
import React from 'react';

const AssetBalance: React.FC = () => {
  return (
    <div className="w-full max-w-md bg-gray-100 rounded-xl p-6 mb-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Trading</h3>
      
      {/* 交易功能模块 */}
      <div className="grid grid-cols-4 gap-4">
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center mb-2 shadow-md hover:shadow-lg transition-shadow duration-300">
            <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
              <span className="text-green-600 font-bold text-xl">+</span>
            </div>
          </div>
          <span className="text-sm text-gray-700 font-medium">Recharge</span>
        </div>
        
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center mb-2 shadow-md hover:shadow-lg transition-shadow duration-300">
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
              <span className="text-blue-600 font-bold text-xl">-</span>
            </div>
          </div>
          <span className="text-sm text-gray-700 font-medium">Withdraw</span>
        </div>
        
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center mb-2 shadow-md hover:shadow-lg transition-shadow duration-300">
            <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
              <span className="text-purple-600 font-bold text-xl">⇄</span>
            </div>
          </div>
          <span className="text-sm text-gray-700 font-medium">Transfer</span>
        </div>
        
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center mb-2 shadow-md hover:shadow-lg transition-shadow duration-300">
            <div className="w-8 h-8 rounded-full bg-yellow-100 flex items-center justify-center">
              <span className="text-yellow-600 font-bold text-xl">📜</span>
            </div>
          </div>
          <span className="text-sm text-gray-700 font-medium">History</span>
        </div>
      </div>
    </div>
  );
};

export default AssetBalance;
