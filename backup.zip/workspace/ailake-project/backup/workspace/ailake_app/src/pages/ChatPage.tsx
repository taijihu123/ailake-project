
import React, { useState } from 'react';
import Header from '../components/layout/Header';
import ChatInput from '../components/ui/ChatInput';
import PlantLogo from '../components/ui/PlantLogo';
import FooterTab from '../components/layout/FooterTab';

const ChatPage: React.FC = () => {
  const [isCallActive, setIsCallActive] = useState(false);
  const [isSubtitleActive, setIsSubtitleActive] = useState(false);

  const endCall = () => {
    setIsCallActive(false);
  };

  const toggleSubtitle = () => {
    setIsSubtitleActive(!isSubtitleActive);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white flex flex-col">
      {/* 顶部导航栏 */}
      <Header />
      
      {/* 主要内容区域 */}
      <main className="flex-1 flex flex-col items-center justify-center p-4 pb-20">
        {/* 通话状态显示区 */}
        {isCallActive && (
          <div className="w-full max-w-md bg-white rounded-xl shadow-md p-6 mb-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                {/* 电话听筒图标 */}
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">通话中</h3>
                  {/* 去掉"与AI助手连接中..."提示和加载动画 */}
                </div>
              </div>
              {/* 添加挂断按钮 */}
              <div className="flex space-x-2">
                {/* 字幕按钮 */}
                <button 
                  className={`font-bold py-2 px-4 rounded-lg transition duration-200 ${
                    isSubtitleActive 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                  }`}
                  onClick={toggleSubtitle}
                >
                  字幕
                </button>
                {/* 挂断按钮 */}
                <button 
                  className="font-bold py-2 px-4 rounded-lg transition duration-200 bg-red-500 hover:bg-red-600 text-white"
                  onClick={endCall}
                >
                  挂断
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* 植物Logo图标 */}
        <PlantLogo />
      </main>
      
      {/* 底部对话输入区 */}
      <ChatInput />
      
      {/* 底部切换栏 */}
      <FooterTab />
    </div>
  );
};

export default ChatPage;
