
import React from 'react';
import Header from '../components/layout/Header';
import FooterTab from '../components/layout/FooterTab';

const PlanetPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white flex flex-col">
      {/* 顶部导航栏 */}
      <Header />
      
      {/* 主要内容区域 */}
      <main className="flex-1 flex flex-col items-center justify-center p-4 pb-20">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">星球页面</h2>
          <p className="text-gray-600 text-lg">这里是星球页面的内容区域</p>
        </div>
      </main>
      
      {/* 底部切换栏 */}
      <FooterTab />
    </div>
  );
};

export default PlanetPage;
