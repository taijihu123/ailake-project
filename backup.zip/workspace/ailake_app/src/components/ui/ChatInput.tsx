import React, { useState } from 'react';

interface ChatInputProps {
  onSend: (message: string) => void;
  disabled?: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSend, disabled = false }) => {
  const [inputValue, setInputValue] = useState('');

  const handleSend = () => {
    if (inputValue.trim() && !disabled) {
      onSend(inputValue);
      setInputValue('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white py-4">
      <div className="max-w-2xl mx-auto">
        {/* 输入框区域 */}
        <div className="flex items-center mb-4 px-4">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="输入消息..."
            disabled={disabled}
            className="flex-1 border border-gray-300 rounded-lg py-3 px-4 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent disabled:bg-gray-100"
          />
          <button
            onClick={handleSend}
            disabled={disabled || !inputValue.trim()}
            className={`font-bold py-3 px-6 rounded-lg ml-2 transition duration-200 ${
              disabled || !inputValue.trim()
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-green-500 hover:bg-green-600 text-white'
            }`}
          >
            发送
          </button>
        </div>
        
        {/* 底部按钮区域 */}
        <div className="flex justify-center items-center space-x-8">
          <button className="w-16 h-8 rounded-full bg-green-500 text-white font-bold flex items-center justify-center transition-all duration-300 transform active:scale-95">
            对话
          </button>
          <button className="w-16 h-8 rounded-full bg-gray-300 text-gray-600 font-bold flex items-center justify-center transition-all duration-300 transform active:scale-95">
            星球
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatInput;