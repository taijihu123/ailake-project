import React from 'react';

const PlantLogo: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center">
      {/* 植物Logo图标 */}
      <div className="w-32 h-32 rounded-full overflow-hidden shadow-lg">
        <img 
          src="/src/assets/images/plant-logo.jpg" 
          alt="Plant Logo" 
          className="w-full h-full object-cover"
        />
      </div>
      <h2 className="mt-4 text-2xl font-bold text-gray-800">Ailake</h2>
    </div>
  );
};

export default PlantLogo;