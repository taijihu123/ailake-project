import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const FooterTab: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-2">
      <div className="max-w-2xl mx-auto flex justify-around items-center">
        <button
          onClick={() => navigate('/')}
          className={`flex flex-col items-center px-4 py-1 rounded-lg transition-colors ${
            isActive('/') 
              ? 'text-green-600' 
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className={`h-6 w-6 ${isActive('/') ? 'text-green-600' : 'text-gray-500'}`} 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" 
            />
          </svg>
          <span className="text-xs mt-1">对话</span>
        </button>
        
        <button
          onClick={() => navigate('/planet')}
          className={`flex flex-col items-center px-4 py-1 rounded-lg transition-colors ${
            isActive('/planet') 
              ? 'text-green-600' 
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className={`h-6 w-6 ${isActive('/planet') ? 'text-green-600' : 'text-gray-500'}`} 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" 
            />
          </svg>
          <span className="text-xs mt-1">星球</span>
        </button>
        
        <button
          onClick={() => navigate('/trade')}
          className={`flex flex-col items-center px-4 py-1 rounded-lg transition-colors ${
            isActive('/trade') 
              ? 'text-green-600' 
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className={`h-6 w-6 ${isActive('/trade') ? 'text-green-600' : 'text-gray-500'}`} 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" 
            />
          </svg>
          <span className="text-xs mt-1">交易</span>
        </button>
      </div>
    </div>
  );
};

export default FooterTab;