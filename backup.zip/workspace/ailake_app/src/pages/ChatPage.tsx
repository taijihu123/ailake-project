import React, { useState, useEffect, useRef } from 'react';
import { sendMessageToDoubao } from '../lib/doubaoApi';
import PlantLogo from '../components/ui/PlantLogo';
import ChatInput from '../components/ui/ChatInput';
import FooterTab from '../components/ui/FooterTab';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const ChatPage: React.FC = () => {
  const [isCallActive, setIsCallActive] = useState(false);
  const [isSubtitleActive, setIsSubtitleActive] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // 滚动到最新消息
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const startCall = () => {
    setIsCallActive(true);
  };

  const endCall = () => {
    setIsCallActive(false);
  };

  const toggleSubtitle = () => {
    setIsSubtitleActive(!isSubtitleActive);
  };

  const handleSend = async (inputValue: string) => {
    if (!inputValue.trim() || isLoading) return;

    // 添加用户消息到聊天记录
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    
    // 设置加载状态
    setIsLoading(true);
    
    try {
      // 准备历史消息（只取最近的几条以避免超出API限制）
      const history = messages.slice(-5).map(msg => ({
        role: msg.role,
        content: msg.content
      }));
      
      // 调用豆包API
      const response = await sendMessageToDoubao(inputValue, history);
      
      // 添加AI助手回复到聊天记录
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      // 添加错误消息到聊天记录
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: '抱歉，我无法处理您的请求。请稍后再试。',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white flex flex-col">
      {/* 顶部导航栏 */}
      <header className="bg-white shadow-sm py-4 px-4">
        <div className="max-w-2xl mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-semibold text-gray-800">Ailake</h1>
            </div>
          </div>
          <div className="flex space-x-2">
            {/* 开始通话按钮 */}
            <button 
              className="p-2 rounded-full bg-green-100 hover:bg-green-200"
              onClick={startCall}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
            </button>
            <button className="p-2 rounded-full bg-gray-100 hover:bg-gray-200">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
              </svg>
            </button>
          </div>
        </div>
      </header>
      
      {/* 主要内容区域 */}
      <main className="flex-1 flex flex-col items-center justify-center p-4 pb-32 overflow-y-auto">
        {/* 通话状态显示区 */}
        {isCallActive && (
          <div className="w-full max-w-md bg-white rounded-xl shadow-md p-6 mb-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                {/* 电话听筒图标 */}
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">通话中</h3>
                </div>
              </div>
              {/* 添加挂断按钮 */}
              <div className="flex space-x-2">
                {/* 字幕按钮 */}
                <button 
                  className={`font-bold py-2 px-4 rounded-lg transition duration-200 ${
                    isSubtitleActive 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                  }`}
                  onClick={toggleSubtitle}
                >
                  字幕
                </button>
                {/* 挂断按钮 */}
                <button 
                  className="font-bold py-2 px-4 rounded-lg transition duration-200 bg-red-500 hover:bg-red-600 text-white"
                  onClick={endCall}
                >
                  挂断
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* 聊天消息显示区 */}
        {!isCallActive && (
          <div className="w-full max-w-2xl flex flex-col">
            {/* 欢迎消息 */}
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8">
                <PlantLogo />
                <h2 className="text-2xl font-bold text-gray-800 mt-4">Ailake</h2>
                <p className="text-gray-600 mt-2">您的AI助手，随时为您服务</p>
              </div>
            )}
            
            {/* 聊天记录 */}
            <div className="space-y-4 py-4">
              {messages.map((message) => (
                <div 
                  key={message.id} 
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div 
                    className={`max-w-xs md:max-w-md px-4 py-2 rounded-lg ${
                      message.role === 'user' 
                        ? 'bg-green-500 text-white rounded-br-none' 
                        : 'bg-white text-gray-800 border border-gray-200 rounded-bl-none'
                    }`}
                  >
                    <p>{message.content}</p>
                    <p 
                      className={`text-xs mt-1 ${
                        message.role === 'user' ? 'text-green-100' : 'text-gray-500'
                      }`}
                    >
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))}
              
              {/* 加载指示器 */}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white border border-gray-200 text-gray-800 px-4 py-2 rounded-lg rounded-bl-none">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200"></div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          </div>
        )}
      </main>
      
      {/* 底部对话输入区 */}
      <ChatInput onSend={handleSend} disabled={isLoading} />
      
      {/* 底部切换栏 */}
      <FooterTab />
    </div>
  );
};

export default ChatPage;