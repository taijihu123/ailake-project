import React from 'react';
import Header from '../components/layout/Header';
import PlantLogo from '../components/ui/PlantLogo';
import AssetBalance from '../components/ui/AssetBalance';
import TransactionHistory from '../components/ui/TransactionHistory';
import ChatInput from '../components/ui/ChatInput';

const HomePage: React.FC = () => {
  // 空的处理函数，因为在主页不需要发送消息
  const handleSend = (message: string) => {
    // 在主页不处理消息发送
    console.log('Message sent from HomePage (not processed):', message);
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* 顶部导航栏 */}
      <Header />
      
      {/* 主要内容区域 */}
      <main className="flex-1 flex flex-col items-center justify-center p-4">
        {/* 植物Logo图标 */}
        <PlantLogo />
        
        {/* 资产余额展示 */}
        <AssetBalance />
        
        {/* 交易历史 */}
        <TransactionHistory />
      </main>
      
      {/* 底部对话输入区 */}
      <ChatInput onSend={handleSend} />
    </div>
  );
};

export default HomePage;