import React from 'react';
import Header from '../components/layout/Header';
import MarketData from '../components/ui/MarketData';
import AssetBalance from '../components/ui/AssetBalance';
import TransactionHistory from '../components/ui/TransactionHistory';
import FooterTab from '../components/layout/FooterTab';

const TradePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white flex flex-col">
      {/* 顶部导航栏 */}
      <Header />
      
      {/* 主要内容区域 */}
      <main className="flex-1 flex flex-col items-center justify-center p-4 pb-20">
        {/* 市场数据展示 */}
        <MarketData />
        
        {/* 资产余额展示 */}
        <AssetBalance />
        
        {/* 交易历史 */}
        <TransactionHistory />
      </main>
      
      {/* 底部切换栏 */}
      <FooterTab />
    </div>
  );
};

export default TradePage;