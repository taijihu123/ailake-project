import React, { createContext, useState, useEffect, useContext } from 'react';

// 定义用户类型
interface User {
  id: string;
  username: string;
  avatarUrl: string;
}

// 定义认证上下文类型
interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (username: string, password: string) => Promise<boolean>;
}

// 创建认证上下文
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// 认证提供者组件
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  // 检查本地存储中是否有用户信息
  useEffect(() => {
    const storedUser = localStorage.getItem('ailake_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  // 登录函数
  const login = async (username: string, _password: string): Promise<boolean> => {
    // 模拟API调用
    // 在实际应用中，这里会调用后端API进行验证
    return new Promise((resolve) => {
      setTimeout(() => {
        // 模拟用户数据
        const mockUser: User = {
          id: '1',
          username,
          avatarUrl: '/src/assets/images/plant-logo.jpg'
        };
        
        setUser(mockUser);
        localStorage.setItem('ailake_user', JSON.stringify(mockUser));
        resolve(true);
      }, 500);
    });
  };

  // 注册函数
  const register = async (username: string, _password: string): Promise<boolean> => {
    // 模拟API调用
    // 在实际应用中，这里会调用后端API创建用户并生成AI头像
    return new Promise((resolve) => {
      setTimeout(() => {
        // 使用我们刚刚添加的植物风格头像
        const mockAvatarUrl = '/src/assets/images/plant-logo.jpg';
        
        // 模拟用户数据
        const newUser: User = {
          id: Math.random().toString(36).substr(2, 9),
          username,
          avatarUrl: mockAvatarUrl
        };
        
        setUser(newUser);
        localStorage.setItem('ailake_user', JSON.stringify(newUser));
        resolve(true);
      }, 500);
    });
  };

  // 登出函数
  const logout = () => {
    setUser(null);
    localStorage.removeItem('ailake_user');
  };

  const value = {
    user,
    login,
    logout,
    register
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

// 自定义hook用于访问认证上下文
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};