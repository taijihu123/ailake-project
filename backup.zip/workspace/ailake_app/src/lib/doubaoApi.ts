import axios from 'axios';

// 豆包API配置
const API_KEY = '0e4ba028-cd1f-428a-93f4-cbcd86c9cf68';
const API_URL = 'https://ark.cn-beijing.volces.com/api/v3/chat/completions'; // 请根据实际API端点调整

// 创建axios实例
const doubaoApi = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${API_KEY}`
  }
});

// 发送消息到豆包API
export const sendMessageToDoubao = async (message: string, history: Array<{role: string, content: string}> = []) => {
  try {
    const response = await doubaoApi.post('', {
      model: "ep-xxxx", // 请根据实际模型ID调整
      messages: [
        ...history,
        {
          role: "user",
          content: message
        }
      ],
      stream: false
    });
    
    return response.data.choices[0].message.content;
  } catch (error) {
    console.error('Error sending message to Doubao API:', error);
    throw new Error('Failed to get response from Doubao API');
  }
};

export default doubaoApi;