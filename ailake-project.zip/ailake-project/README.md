# Ailake Project

This repository contains the AIC virtual asset trading page and related files.

## Files included:
- aic-trading-page.html: Main HTML structure
- aic-trading-style.css: CSS styling
- aic-trading-script.js: JavaScript functionality
- aic-trading-page-screenshot.png: Screenshot of the page
- aic-static.zip: Compressed archive of all files

## Setup
To use these files, simply open aic-trading-page.html in a web browser.
