// aic-trading-script.js

// 获取DOM元素
const rechargeBtn = document.getElementById('rechargeBtn');
const withdrawBtn = document.getElementById('withdrawBtn');
const transferBtn = document.getElementById('transferBtn');
const historyBtn = document.getElementById('historyBtn');

const rechargeCard = document.getElementById('rechargeCard');
const withdrawCard = document.getElementById('withdrawCard');
const transferCard = document.getElementById('transferCard');
const historyCard = document.getElementById('historyCard');

// 弹窗元素
const rechargeModal = document.getElementById('rechargeModal');
const withdrawModal = document.getElementById('withdrawModal');
const transferModal = document.getElementById('transferModal');
const closeRecharge = document.getElementById('closeRecharge');
const closeWithdraw = document.getElementById('closeWithdraw');
const closeTransfer = document.getElementById('closeTransfer');

// 确认按钮
const confirmRecharge = document.getElementById('confirmRecharge');
const confirmWithdraw = document.getElementById('confirmWithdraw');
const confirmTransfer = document.getElementById('confirmTransfer');

// Tab栏元素
const chatTab = document.getElementById('chatTab');
const planetTab = document.getElementById('planetTab');

// 用户资产
let userAssets = 1000.00;

// 更新资产显示
function updateAssets() {
    const assetsElement = document.querySelector('.user-assets');
    assetsElement.textContent = `资产: $\{userAssets.toFixed(2)\}`;
}

// 显示弹窗
function showModal(modal) {
    modal.style.display = 'block';
}

// 隐藏弹窗
function hideModal(modal) {
    modal.style.display = 'none';
}

// 充值功能
rechargeBtn.addEventListener('click', () => {
    showModal(rechargeModal);
});

// 提现功能
withdrawBtn.addEventListener('click', () => {
    showModal(withdrawModal);
});

// 转账功能
transferBtn.addEventListener('click', () => {
    showModal(transferModal);
});

// 历史记录功能
historyBtn.addEventListener('click', () => {
    alert('历史记录功能待实现');
});

// 关闭弹窗
closeRecharge.addEventListener('click', () => {
    hideModal(rechargeModal);
});

closeWithdraw.addEventListener('click', () => {
    hideModal(withdrawModal);
});

closeTransfer.addEventListener('click', () => {
    hideModal(transferModal);
});

// 点击弹窗外部关闭
window.addEventListener('click', (event) => {
    if (event.target === rechargeModal) {
        hideModal(rechargeModal);
    }
    if (event.target === withdrawModal) {
        hideModal(withdrawModal);
    }
    if (event.target === transferModal) {
        hideModal(transferModal);
    }
});

// 确认充值
confirmRecharge.addEventListener('click', (event) => {
    event.preventDefault();
    const amount = parseFloat(document.getElementById('rechargeAmount').value);
    if (amount && amount > 0) {
        userAssets += amount;
        updateAssets();
        hideModal(rechargeModal);
        document.getElementById('rechargeAmount').value = '';
        alert(`成功充值 $\{amount.toFixed(2)\} AIC`);
    } else {
        alert('请输入有效的充值金额');
    }
});

// 确认提现
confirmWithdraw.addEventListener('click', (event) => {
    event.preventDefault();
    const amount = parseFloat(document.getElementById('withdrawAmount').value);
    if (amount && amount > 0 && amount <= userAssets) {
        userAssets -= amount;
        updateAssets();
        hideModal(withdrawModal);
        document.getElementById('withdrawAmount').value = '';
        alert(`成功提现 $\{amount.toFixed(2)\} AIC`);
    } else if (amount > userAssets) {
        alert('余额不足');
    } else {
        alert('请输入有效的提现金额');
    }
});

// 确认转账
confirmTransfer.addEventListener('click', (event) => {
    event.preventDefault();
    const to = document.getElementById('transferTo').value;
    const amount = parseFloat(document.getElementById('transferAmount').value);
    if (to && amount && amount > 0 && amount <= userAssets) {
        userAssets -= amount;
        updateAssets();
        hideModal(transferModal);
        document.getElementById('transferTo').value = '';
        document.getElementById('transferAmount').value = '';
        alert(`成功转账 $\{amount.toFixed(2)\} AIC 给 $\{to}`);
    } else if (amount > userAssets) {
        alert('余额不足');
    } else {
        alert('请输入有效的转账信息');
    }
});

// Tab切换功能
chatTab.addEventListener('click', () => {
    chatTab.classList.add('active');
    planetTab.classList.remove('active');
    alert('跳转到对话页面');
});

planetTab.addEventListener('click', () => {
    planetTab.classList.add('active');
    chatTab.classList.remove('active');
    alert('跳转到星球页面');
});

// 初始化资产显示
updateAssets();
