// final-script.js

// 获取DOM元素
const loginBtn = document.querySelector('.login-btn');
const signupBtn = document.querySelector('.signup-btn');
const primaryBtn = document.querySelector('.primary-btn');
const secondaryBtn = document.querySelector('.secondary-btn');

// 登录按钮点击事件
loginBtn.addEventListener('click', () => {
    alert('登录功能待实现');
});

// 免费试用按钮点击事件
signupBtn.addEventListener('click', () => {
    alert('免费试用功能待实现');
});

// 立即开始按钮点击事件
primaryBtn.addEventListener('click', () => {
    alert('立即开始使用Ailake智能助手');
});

// 观看演示按钮点击事件
secondaryBtn.addEventListener('click', () => {
    alert('观看Ailake智能助手演示视频');
});

// 功能标签切换
const tabBtns = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.feature-tab-content');

tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        // 移除所有激活状态
        tabBtns.forEach(b => b.classList.remove('active'));
        tabContents.forEach(c => c.classList.remove('active'));
        
        // 添加当前激活状态
        btn.classList.add('active');
        const tabId = btn.getAttribute('data-tab');
        document.getElementById(tabId).classList.add('active');
    });
});

// 定价卡片按钮事件
const pricingCards = document.querySelectorAll('.pricing-card');
pricingCards.forEach(card => {
    const button = card.querySelector('button');
    button.addEventListener('click', () => {
        if (button.classList.contains('primary-btn')) {
            alert('购买专业版服务');
        } else if (button.textContent.includes('免费试用')) {
            alert('开始免费试用');
        } else {
            alert('联系销售团队');
        }
    });
});

// 导航链接点击事件
const navLinks = document.querySelectorAll('.nav-menu a');
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        alert(`导航到 $\{link.textContent\} 页面`);
    });
});
