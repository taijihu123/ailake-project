// enhanced-script.js

// 获取DOM元素
const loginBtn = document.querySelector('.login-btn');
const signupBtn = document.querySelector('.signup-btn');
const primaryBtn = document.querySelector('.primary-btn');
const secondaryBtn = document.querySelector('.secondary-btn');

// 登录按钮点击事件
loginBtn.addEventListener('click', () => {
    alert('登录功能待实现');
});

// 免费试用按钮点击事件
signupBtn.addEventListener('click', () => {
    alert('免费试用功能待实现');
});

// 立即开始按钮点击事件
primaryBtn.addEventListener('click', () => {
    alert('立即开始使用Ailake智能助手');
});

// 观看演示按钮点击事件
secondaryBtn.addEventListener('click', () => {
    alert('观看Ailake智能助手演示视频');
});

// 功能卡片点击事件
const featureCards = document.querySelectorAll('.feature-card');
featureCards.forEach((card, index) => {
    card.addEventListener('click', () => {
        switch(index) {
            case 0:
                alert('智能对话功能详情');
                break;
            case 1:
                alert('任务管理功能详情');
                break;
            case 2:
                alert('知识库功能详情');
                break;
            case 3:
                alert('数据分析功能详情');
                break;
        }
    });
});

// 导航链接点击事件
const navLinks = document.querySelectorAll('.nav-menu a');
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        alert(`导航到 $\{link.textContent\} 页面`);
    });
});
