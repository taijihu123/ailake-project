// chat-script.js

// 获取DOM元素
const chatHistory = document.getElementById('chatHistory');
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendButton');
const chatTab = document.getElementById('chatTab');
const planetTab = document.getElementById('planetTab');

// 添加消息到聊天历史
function addMessage(sender, content) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message $\{sender\}`;
    
    const senderDiv = document.createElement('div');
    senderDiv.className = 'message-sender';
    senderDiv.textContent = sender === 'user' ? '您' : 'Ailake助手';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.textContent = content;
    
    messageDiv.appendChild(senderDiv);
    messageDiv.appendChild(contentDiv);
    chatHistory.appendChild(messageDiv);
    
    // 滚动到底部
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

// 发送消息
function sendMessage() {
    const message = messageInput.value.trim();
    if (message) {
        // 添加用户消息
        addMessage('user', message);
        
        // 清空输入框
        messageInput.value = '';
        
        // 模拟助手回复
        setTimeout(() => {
            addMessage('assistant', `您说: "$\{message\}"。我是Ailake智能助手，我收到了您的消息。请问有什么可以帮助您的吗？`);
        }, 1000);
    }
}

// 事件监听器
sendButton.addEventListener('click', sendMessage);

messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

// Tab切换功能
chatTab.addEventListener('click', () => {
    chatTab.classList.add('active');
    planetTab.classList.remove('active');
    alert('当前已在对话页面');
});

planetTab.addEventListener('click', () => {
    planetTab.classList.add('active');
    chatTab.classList.remove('active');
    alert('跳转到星球页面');
});

// 初始化聊天历史
addMessage('assistant', '您好！我是Ailake智能助手，有什么可以帮助您的吗？');
