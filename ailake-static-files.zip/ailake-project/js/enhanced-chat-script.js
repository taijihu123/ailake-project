// enhanced-chat-script.js

// 获取DOM元素
const chatHistory = document.getElementById('chatHistory');
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendButton');
const attachButton = document.getElementById('attachButton');
const emojiButton = document.getElementById('emojiButton');
const clearChatButton = document.getElementById('clearChat');
const saveChatButton = document.getElementById('saveChat');
const chatTab = document.getElementById('chatTab');
const planetTab = document.getElementById('planetTab');

// 自动调整textarea高度
function adjustTextareaHeight() {
    messageInput.style.height = 'auto';
    messageInput.style.height = (messageInput.scrollHeight > 150 ? 150 : messageInput.scrollHeight) + 'px';
}

// 添加消息到聊天历史
function addMessage(sender, content) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message $\{sender\}`;
    
    const senderDiv = document.createElement('div');
    senderDiv.className = 'message-sender';
    senderDiv.textContent = sender === 'user' ? '您' : 'Ailake助手';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.textContent = content;
    
    messageDiv.appendChild(senderDiv);
    messageDiv.appendChild(contentDiv);
    chatHistory.appendChild(messageDiv);
    
    // 滚动到底部
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

// 发送消息
function sendMessage() {
    const message = messageInput.value.trim();
    if (message) {
        // 添加用户消息
        addMessage('user', message);
        
        // 清空输入框
        messageInput.value = '';
        adjustTextareaHeight();
        
        // 模拟助手回复
        setTimeout(() => {
            addMessage('assistant', `您说: "$\{message\}"。我是Ailake智能助手，我收到了您的消息。请问有什么可以帮助您的吗？`);
        }, 1000);
    }
}

// 事件监听器
sendButton.addEventListener('click', sendMessage);

messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
});

messageInput.addEventListener('input', adjustTextareaHeight);

// 附件按钮
attachButton.addEventListener('click', () => {
    alert('附件功能待实现');
});

// 表情按钮
emojiButton.addEventListener('click', () => {
    alert('表情功能待实现');
});

// 清空对话
clearChatButton.addEventListener('click', () => {
    if (confirm('确定要清空所有对话记录吗？')) {
        chatHistory.innerHTML = '';
        addMessage('assistant', '对话记录已清空。您好！我是Ailake智能助手，有什么可以帮助您的吗？');
    }
});

// 保存对话
saveChatButton.addEventListener('click', () => {
    alert('对话已保存');
});

// Tab切换功能
chatTab.addEventListener('click', () => {
    chatTab.classList.add('active');
    planetTab.classList.remove('active');
    alert('当前已在对话页面');
});

planetTab.addEventListener('click', () => {
    planetTab.classList.add('active');
    chatTab.classList.remove('active');
    alert('跳转到星球页面');
});

// 初始化聊天历史
addMessage('assistant', '您好！我是Ailake智能助手，有什么可以帮助您的吗？');
