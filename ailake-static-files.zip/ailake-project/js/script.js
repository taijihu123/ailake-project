// script.js

// 获取DOM元素
const loginBtn = document.querySelector('.login-btn');
const signupBtn = document.querySelector('.signup-btn');
const primaryBtn = document.querySelector('.primary-btn');
const secondaryBtn = document.querySelector('.secondary-btn');

// 登录按钮点击事件
loginBtn.addEventListener('click', () => {
    alert('登录功能待实现');
});

// 注册按钮点击事件
signupBtn.addEventListener('click', () => {
    alert('注册功能待实现');
});

// 开始使用按钮点击事件
primaryBtn.addEventListener('click', () => {
    alert('开始使用Ailake智能助手');
});

// 了解更多按钮点击事件
secondaryBtn.addEventListener('click', () => {
    alert('了解更多关于Ailake智能助手的信息');
});

// 功能卡片点击事件
const featureCards = document.querySelectorAll('.feature-card');
featureCards.forEach((card, index) => {
    card.addEventListener('click', () => {
        switch(index) {
            case 0:
                alert('智能对话功能详情');
                break;
            case 1:
                alert('任务管理功能详情');
                break;
            case 2:
                alert('知识库功能详情');
                break;
        }
    });
});
