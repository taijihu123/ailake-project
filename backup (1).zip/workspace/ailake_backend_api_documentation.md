
# Ailake App 后端API接口文档

## 1. 用户与AI头像模块

### 1.1 用户注册
**接口地址**: `POST /api/user/register`  
**请求参数**:
```json
{
  "username": "string",
  "password": "string"
}
```
**响应数据**:
```json
{
  "success": true,
  "data": {
    "user_id": "string",
    "username": "string",
    "avatar_url": "string",
    "token": "string"
  },
  "message": "注册成功"
}
```
**逻辑说明**: 
注册时调用AI头像生成服务（比如对接Stable Diffusion、第三方AI绘图API），将生成的头像URL与用户账号绑定；登录时返回用户信息（含头像URL），供前端渲染。

### 1.2 用户登录
**接口地址**: `POST /api/user/login`  
**请求参数**:
```json
{
  "username": "string",
  "password": "string"
}
```
**响应数据**:
```json
{
  "success": true,
  "data": {
    "user_id": "string",
    "username": "string",
    "avatar_url": "string",
    "token": "string"
  },
  "message": "登录成功"
}
```

### 1.3 获取当前用户头像
**接口地址**: `GET /api/user/avatar`  
**请求头**: 
```
Authorization: Bearer <token>
```
**响应数据**:
```json
{
  "success": true,
  "data": {
    "avatar_url": "string"
  },
  "message": "获取成功"
}
```

### 1.4 更新用户头像
**接口地址**: `POST /api/user/avatar/update`  
**请求头**: 
```
Authorization: Bearer <token>
```
**请求参数**:
```json
{
  "avatar_url": "string"
}
```
**响应数据**:
```json
{
  "success": true,
  "data": {
    "avatar_url": "string"
  },
  "message": "更新成功"
}
```

## 2. 对话模块

### 2.1 通话发起
**接口地址**: `POST /api/call/start`  
**请求头**: 
```
Authorization: Bearer <token>
```
**请求参数**:
```json
{
  "device_info": "string"
}
```
**响应数据**:
```json
{
  "success": true,
  "data": {
    "call_token": "string",
    "websocket_url": "string"
  },
  "message": "通话已建立"
}
```

### 2.2 通话结束
**接口地址**: `POST /api/call/end`  
**请求头**: 
```
Authorization: Bearer <token>
```
**请求参数**:
```json
{
  "call_token": "string"
}
```
**响应数据**:
```json
{
  "success": true,
  "data": {
    "duration": "number",
    "interaction_count": "number"
  },
  "message": "通话已结束"
}
```

### 2.3 获取对话历史
**接口地址**: `GET /api/chat/history`  
**请求头**: 
```
Authorization: Bearer <token>
```
**响应数据**:
```json
{
  "success": true,
  "data": [
    {
      "id": "string",
      "content": "string",
      "timestamp": "string",
      "sender": "user|ai"
    }
  ],
  "message": "获取成功"
}
```

## 3. 交易模块

### 3.1 获取交易数据
**接口地址**: `GET /api/trade/data`  
**请求头**: 
```
Authorization: Bearer <token>
```
**响应数据**:
```json
{
  "success": true,
  "data": {
    "price": "number",
    "change_24h": "number",
    "volume_24h": "number",
    "turnover_24h": "number"
  },
  "message": "获取成功"
}
```

### 3.2 充值
**接口地址**: `POST /api/trade/recharge`  
**请求头**: 
```
Authorization: Bearer <token>
```
**请求参数**:
```json
{
  "amount": "number",
  "payment_method": "string"
}
```
**响应数据**:
```json
{
  "success": true,
  "data": {
    "transaction_id": "string",
    "new_balance": "number"
  },
  "message": "充值成功"
}
```

### 3.3 提现
**接口地址**: `POST /api/trade/withdraw`  
**请求头**: 
```
Authorization: Bearer <token>
```
**请求参数**:
```json
{
  "amount": "number",
  "bank_account": "string"
}
```
**响应数据**:
```json
{
  "success": true,
  "data": {
    "transaction_id": "string",
    "new_balance": "number"
  },
  "message": "提现申请已提交"
}
```

### 3.4 转账
**接口地址**: `POST /api/trade/transfer`  
**请求头**: 
```
Authorization: Bearer <token>
```
**请求参数**:
```json
{
  "to_user_id": "string",
  "amount": "number",
  "remark": "string"
}
```
**响应数据**:
```json
{
  "success": true,
  "data": {
    "transaction_id": "string",
    "new_balance": "number"
  },
  "message": "转账成功"
}
```

### 3.5 获取交易历史
**接口地址**: `GET /api/trade/history`  
**请求头**: 
```
Authorization: Bearer <token>
```
**响应数据**:
```json
{
  "success": true,
  "data": [
    {
      "id": "string",
      "type": "recharge|withdraw|transfer",
      "amount": "number",
      "timestamp": "string",
      "status": "completed|pending|failed"
    }
  ],
  "message": "获取成功"
}
```

## 4. 错误响应格式

所有接口在出错时都会返回以下格式的响应：

```json
{
  "success": false,
  "error": {
    "code": "number",
    "message": "string"
  }
}
```

### 常见错误码
- 400: 请求参数错误
- 401: 未授权访问
- 404: 资源不存在
- 500: 服务器内部错误

## 5. WebSocket连接

对于实时通话功能，需要通过WebSocket建立连接：

**连接地址**: `ws://xxx/api/chat/stream`  
**连接参数**: 
```
Authorization: Bearer <call_token>
```

**消息格式**:
```json
{
  "type": "audio|text",
  "content": "base64 encoded audio data or text",
  "timestamp": "string"
}
```

**响应格式**:
```json
{
  "type": "audio|text",
  "content": "base64 encoded audio data or text",
  "timestamp": "string"
}
```
