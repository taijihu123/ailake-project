
# Ailake App APK 下载说明

## 项目状态

本项目已成功完成以下所有开发和打包步骤：
1. 创建了完整的Ailake Web应用程序，包含对话、交易和星球三个独立页面
2. 实现了完整的后端API服务，包括用户认证、交易功能和对话功能
3. 使用Capacitor将Web应用打包为Android项目
4. 前端资源已成功同步到Android工程

## APK生成步骤

由于当前环境限制，APK文件需要在Android Studio中编译生成。请按照以下步骤操作：

### 1. 打开Android工程
- 进入项目目录：`/home/admin/workspace/ailake_app`
- 找到android文件夹，使用Android Studio打开整个android项目

### 2. 编译APK
在Android Studio中：
1. 点击顶部菜单栏的 Build → Build Bundle(s) / APK(s) → Build APK(s)
2. 等待编译完成（过程中会显示进度）
3. 若有错误会提示，需根据错误信息修复（比如SDK版本不匹配、签名配置问题等）

### 3. 获取APK文件
编译成功后，APK文件将生成在以下目录：
- 调试版：`/home/admin/workspace/ailake_app/android/app/build/outputs/apk/debug/app-debug.apk`
- 发布版：`/home/admin/workspace/ailake_app/android/app/build/outputs/apk/release/app-release.apk`（需要提前配置签名信息）

## 项目文件结构

```
/home/admin/workspace/ailake_app/
├── src/                    # 前端源代码
│   ├── components/         # UI组件
│   ├── pages/              # 页面组件
│   ├── contexts/           # React上下文
│   └── assets/             # 静态资源
├── dist/                   # 前端构建输出
├── android/                # Android原生项目
│   ├── app/                # 应用模块
│   │   ├── src/            # 源代码
│   │   ├── build/          # 构建输出
│   │   └── build.gradle    # 构建配置
│   └── build.gradle        # 项目级构建配置
└── capacitor.config.ts     # Capacitor配置文件
```

## 后端服务

后端API服务已实现并测试通过，包含以下功能模块：
1. 用户认证系统（注册、登录、JWT令牌管理）
2. 用户专属AI头像生成和管理
3. 交易功能模块（充值、提现、转账、交易历史）
4. 对话功能模块（发送消息、获取对话历史）

## 注意事项

1. 如果需要在非调试设备上安装APK，必须生成签名的发布版APK
2. 后端服务默认运行在本地3000端口，如需在移动设备上访问，需要将后端部署到公网或使用同一局域网内的IP地址
3. Android应用需要网络权限才能访问后端API，请确保在AndroidManifest.xml中已声明相关权限

## 技术支持

如在APK生成过程中遇到任何问题，请参考以下文档：
- Capacitor官方文档：https://capacitorjs.com/docs
- Android开发文档：https://developer.android.com/studio/build
