
import React from 'react';

const PlantLogo: React.FC = () => {
  return (
    <div className="plant-logo-container">
      {/* 植物Logo图标 */}
      <div className="plant-logo-image">
        <img 
          src="/src/assets/images/mmexport1756125394485.jpg" 
          alt="Plant Logo" 
          className="w-full h-full rounded-full object-cover"
        />
      </div>
      <h2 className="plant-logo-text">Ailake</h2>
    </div>
  );
};

export default PlantLogo;
