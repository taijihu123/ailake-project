
import React from 'react';
import Header from '../components/layout/Header';
import PlantLogo from '../components/ui/PlantLogo';
import AssetBalance from '../components/ui/AssetBalance';
import TransactionHistory from '../components/ui/TransactionHistory';
import ChatInput from '../components/ui/ChatInput';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* 顶部导航栏 */}
      <Header />
      
      {/* 主要内容区域 */}
      <main className="flex-1 flex flex-col items-center justify-center p-4">
        {/* 植物Logo图标 */}
        <PlantLogo />
        
        {/* 资产余额展示 */}
        <AssetBalance />
        
        {/* 交易历史 */}
        <TransactionHistory />
      </main>
      
      {/* 底部对话输入区 */}
      <ChatInput />
    </div>
  );
};

export default HomePage;
