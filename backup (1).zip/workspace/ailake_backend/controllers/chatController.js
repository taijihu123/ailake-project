
// 简化的内存存储（在实际应用中，这会被替换为数据库）
const chatMessages = new Map();

// 生成AI回复的模拟函数
const generateAIReply = async (message) => {
  // 在实际应用中，这里会调用AI对话服务（如OpenAI、自研模型等）
  // 生成与用户消息相关的回复
  
  // 模拟生成回复
  const replies = [
    "感谢您的消息，我已经收到了。",
    "这是一个很好的问题，让我来为您解答。",
    "我理解您的需求，正在处理中。",
    "请稍等，我正在思考如何更好地回答您。",
    "根据您提供的信息，我建议您可以尝试以下方案。",
    "这个问题很有趣，让我为您提供更多信息。"
  ];
  
  // 随机选择一个回复
  return replies[Math.floor(Math.random() * replies.length)];
};

// 发送消息
exports.sendMessage = async (req, res) => {
  try {
    const { content } = req.body;
    const userId = req.user.userId;
    const username = req.user.username;

    // 验证参数
    if (!content || content.trim() === '') {
      return res.status(400).json({
        success: false,
        error: {
          code: 400,
          message: '消息内容不能为空'
        }
      });
    }

    // 生成AI回复
    const aiReply = await generateAIReply(content);

    // 创建消息记录
    const messageId = Date.now().toString();
    const timestamp = new Date().toISOString();
    
    const userMessage = {
      id: messageId + "-user",
      user_id: userId,
      username: username,
      type: "user",
      content: content,
      timestamp: timestamp
    };
    
    const aiMessage = {
      id: messageId + "-ai",
      user_id: userId,
      username: "AI助手",
      type: "ai",
      content: aiReply,
      timestamp: new Date(Date.now() + 1000).toISOString() // AI回复稍晚于用户消息
    };

    // 存储消息
    if (!chatMessages.has(userId)) {
      chatMessages.set(userId, []);
    }
    
    const userMessages = chatMessages.get(userId);
    userMessages.push(userMessage);
    userMessages.push(aiMessage);

    res.status(200).json({
      success: true,
      data: {
        user_message: userMessage,
        ai_message: aiMessage
      },
      message: "消息发送成功"
    });
  } catch (error) {
    console.error('发送消息错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};

// 获取对话历史
exports.getChatHistory = async (req, res) => {
  try {
    const userId = req.user.userId;
    
    // 获取用户消息历史
    const userMessages = chatMessages.get(userId) || [];
    
    // 按时间排序
    userMessages.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

    res.status(200).json({
      success: true,
      data: userMessages,
      message: "获取成功"
    });
  } catch (error) {
    console.error('获取对话历史错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};

// 清除对话历史
exports.clearChatHistory = async (req, res) => {
  try {
    const userId = req.user.userId;
    
    // 清除用户消息历史
    chatMessages.delete(userId);

    res.status(200).json({
      success: true,
      message: "对话历史已清除"
    });
  } catch (error) {
    console.error('清除对话历史错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};
