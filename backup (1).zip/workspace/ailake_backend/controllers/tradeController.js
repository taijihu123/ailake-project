
// 简化的内存存储（在实际应用中，这会被替换为数据库）
const tradeData = {
  price: 1.25,
  change24h: 5.2,
  volume24h: 1200000,
  turnover24h: 1500000
};

const transactions = [
  {
    id: "1",
    type: "purchase",
    description: "AI Coin Purchase",
    amount: -1000.00,
    currency: "AIC",
    timestamp: "2024-09-03T10:30:00Z"
  },
  {
    id: "2",
    type: "reward",
    description: "Content Creation Reward",
    amount: 50.00,
    currency: "AIC",
    timestamp: "2024-09-02T14:15:00Z"
  },
  {
    id: "3",
    type: "reward",
    description: "Knowledge Q&A Reward",
    amount: 30.00,
    currency: "AIC",
    timestamp: "2024-09-01T16:45:00Z"
  }
];

// 获取交易数据
exports.getTradeData = async (req, res) => {
  try {
    res.status(200).json({
      success: true,
      data: tradeData,
      message: "获取成功"
    });
  } catch (error) {
    console.error('获取交易数据错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};

// 充值
exports.recharge = async (req, res) => {
  try {
    const { amount, payment_method } = req.body;
    const userId = req.user.userId;

    // 验证参数
    if (!amount || amount <= 0) {
      return res.status(400).json({
        success: false,
        error: {
          code: 400,
          message: '充值金额必须大于0'
        }
      });
    }

    // 模拟充值处理
    // 在实际应用中，这里会调用支付网关处理支付
    
    // 生成交易记录
    const transaction = {
      id: Date.now().toString(),
      user_id: userId,
      type: "recharge",
      amount: parseFloat(amount),
      payment_method: payment_method || "unknown",
      status: "completed",
      timestamp: new Date().toISOString()
    };
    
    // 添加到交易历史
    transactions.push(transaction);

    res.status(200).json({
      success: true,
      data: {
        transaction_id: transaction.id,
        amount: transaction.amount
      },
      message: "充值成功"
    });
  } catch (error) {
    console.error('充值错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};

// 提现
exports.withdraw = async (req, res) => {
  try {
    const { amount, bank_account } = req.body;
    const userId = req.user.userId;

    // 验证参数
    if (!amount || amount <= 0) {
      return res.status(400).json({
        success: false,
        error: {
          code: 400,
          message: '提现金额必须大于0'
        }
      });
    }

    // 模拟提现处理
    // 在实际应用中，这里会验证用户余额并处理提现请求
    
    // 生成交易记录
    const transaction = {
      id: Date.now().toString(),
      user_id: userId,
      type: "withdraw",
      amount: -parseFloat(amount), // 负数表示支出
      bank_account: bank_account || "unknown",
      status: "pending",
      timestamp: new Date().toISOString()
    };
    
    // 添加到交易历史
    transactions.push(transaction);

    res.status(200).json({
      success: true,
      data: {
        transaction_id: transaction.id,
        amount: Math.abs(transaction.amount)
      },
      message: "提现申请已提交"
    });
  } catch (error) {
    console.error('提现错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};

// 转账
exports.transfer = async (req, res) => {
  try {
    const { to_user_id, amount, remark } = req.body;
    const userId = req.user.userId;

    // 验证参数
    if (!to_user_id || !amount || amount <= 0) {
      return res.status(400).json({
        success: false,
        error: {
          code: 400,
          message: '接收用户和转账金额不能为空，且金额必须大于0'
        }
      });
    }

    // 模拟转账处理
    // 在实际应用中，这里会验证用户余额并处理转账请求
    
    // 生成转出交易记录
    const transferOut = {
      id: Date.now().toString() + "-out",
      user_id: userId,
      to_user_id: to_user_id,
      type: "transfer_out",
      amount: -parseFloat(amount), // 负数表示支出
      remark: remark || "",
      status: "completed",
      timestamp: new Date().toISOString()
    };
    
    // 生成转入交易记录
    const transferIn = {
      id: Date.now().toString() + "-in",
      user_id: to_user_id,
      from_user_id: userId,
      type: "transfer_in",
      amount: parseFloat(amount), // 正数表示收入
      remark: remark || "",
      status: "completed",
      timestamp: new Date().toISOString()
    };
    
    // 添加到交易历史
    transactions.push(transferOut);
    transactions.push(transferIn);

    res.status(200).json({
      success: true,
      data: {
        transaction_id: transferOut.id,
        amount: Math.abs(transferOut.amount)
      },
      message: "转账成功"
    });
  } catch (error) {
    console.error('转账错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};

// 获取交易历史
exports.getTradeHistory = async (req, res) => {
  try {
    const userId = req.user.userId;
    
    // 过滤当前用户的交易记录
    const userTransactions = transactions.filter(t => t.user_id === userId);
    
    // 按时间倒序排列
    userTransactions.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    res.status(200).json({
      success: true,
      data: userTransactions,
      message: "获取成功"
    });
  } catch (error) {
    console.error('获取交易历史错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};
