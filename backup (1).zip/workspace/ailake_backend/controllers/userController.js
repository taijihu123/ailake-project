
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

// 简化的内存存储（在实际应用中，这会被替换为数据库）
const users = new Map();
const userSessions = new Map();

// 生成AI头像的模拟函数
const generateAIHeadshot = async (userId) => {
  // 在实际应用中，这里会调用AI绘图服务（如Stable Diffusion、DALL·E等）
  // 生成与用户关联的专属AI头像，并返回头像URL
  
  // 模拟生成头像URL
  // 在实际应用中，这会是AI服务返回的真实URL
  return `/src/assets/images/1757584807113.jpeg`;
};

// 用户注册
exports.register = async (req, res) => {
  try {
    const { username, password } = req.body;

    // 检查用户名是否已存在
    for (let [key, user] of users) {
      if (user.username === username) {
        return res.status(400).json({
          success: false,
          error: {
            code: 400,
            message: '用户名已存在'
          }
        });
      }
    }

    // 加密密码
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // 生成用户ID
    const userId = uuidv4();

    // 生成AI头像
    const avatarUrl = await generateAIHeadshot(userId);

    // 创建用户
    const user = {
      userId,
      username,
      password: hashedPassword,
      avatarUrl,
      createdAt: new Date().toISOString()
    };

    // 保存用户到内存存储
    users.set(userId, user);

    // 生成JWT令牌
    const token = jwt.sign(
      { userId: user.userId, username: user.username },
      process.env.JWT_SECRET || 'ailake_default_secret',
      { expiresIn: '24h' }
    );

    res.status(201).json({
      success: true,
      data: {
        user_id: user.userId,
        username: user.username,
        avatar_url: user.avatarUrl,
        token
      },
      message: '注册成功'
    });
  } catch (error) {
    console.error('注册错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};

// 用户登录
exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;

    // 查找用户
    let user = null;
    for (let [key, u] of users) {
      if (u.username === username) {
        user = u;
        break;
      }
    }

    if (!user) {
      return res.status(400).json({
        success: false,
        error: {
          code: 400,
          message: '用户名或密码错误'
        }
      });
    }

    // 验证密码
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({
        success: false,
        error: {
          code: 400,
          message: '用户名或密码错误'
        }
      });
    }

    // 生成JWT令牌
    const token = jwt.sign(
      { userId: user.userId, username: user.username },
      process.env.JWT_SECRET || 'ailake_default_secret',
      { expiresIn: '24h' }
    );

    res.status(200).json({
      success: true,
      data: {
        user_id: user.userId,
        username: user.username,
        avatar_url: user.avatarUrl,
        token
      },
      message: '登录成功'
    });
  } catch (error) {
    console.error('登录错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};

// 获取用户头像
exports.getAvatar = async (req, res) => {
  try {
    const userId = req.user.userId;

    // 查找用户
    const user = users.get(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: {
          code: 404,
          message: '用户不存在'
        }
      });
    }

    res.status(200).json({
      success: true,
      data: {
        avatar_url: user.avatarUrl
      },
      message: '获取成功'
    });
  } catch (error) {
    console.error('获取头像错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};

// 更新用户头像
exports.updateAvatar = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { avatar_url } = req.body;

    // 查找用户
    const user = users.get(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: {
          code: 404,
          message: '用户不存在'
        }
      });
    }

    // 更新用户头像
    user.avatarUrl = avatar_url;
    users.set(userId, user);

    res.status(200).json({
      success: true,
      data: {
        avatar_url: user.avatarUrl
      },
      message: '更新成功'
    });
  } catch (error) {
    console.error('更新头像错误:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 500,
        message: '服务器内部错误'
      }
    });
  }
};
