
// COZE智能体集成模块
class CozeIntegration {
  constructor(apiToken, botId) {
    this.apiToken = apiToken;
    this.botId = botId;
    this.apiUrl = 'https://api.coze.cn/v3/chat';
    this.conversationId = null;
  }

  // 设置API令牌
  setApiToken(token) {
    this.apiToken = token;
  }

  // 设置Bot ID
  setBotId(botId) {
    this.botId = botId;
  }

  // 创建会话
  async createConversation() {
    try {
      const response = await fetch('https://api.coze.cn/v1/conversation/create', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiToken}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        this.conversationId = data.data.id;
        return data;
      } else {
        throw new Error(`Failed to create conversation: ${response.status}`);
      }
    } catch (error) {
      console.error('Error creating conversation:', error);
      throw error;
    }
  }

  // 发起对话
  async chat(message, userId = 'user123') {
    try {
      // 如果还没有会话ID，先创建一个会话
      if (!this.conversationId) {
        await this.createConversation();
      }

      const requestBody = {
        bot_id: this.botId,
        user_id: userId,
        stream: false, // 简化处理，使用非流式响应
        additional_messages: [
          {
            role: 'user',
            content: message,
            content_type: 'text'
          }
        ]
      };

      // 如果有会话ID，添加到请求参数中
      if (this.conversationId) {
        requestBody.conversation_id = this.conversationId;
      }

      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestBody)
      });

      if (response.ok) {
        const data = await response.json();
        return data;
      } else {
        throw new Error(`Chat request failed: ${response.status}`);
      }
    } catch (error) {
      console.error('Error in chat:', error);
      throw error;
    }
  }

  // 清除上下文
  async clearContext() {
    if (!this.conversationId) {
      console.warn('No conversation to clear');
      return;
    }

    try {
      const response = await fetch(`https://api.coze.cn/v1/conversation/${this.conversationId}/clear`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        return data;
      } else {
        throw new Error(`Failed to clear context: ${response.status}`);
      }
    } catch (error) {
      console.error('Error clearing context:', error);
      throw error;
    }
  }
}

// 导出模块
window.CozeIntegration = CozeIntegration;
