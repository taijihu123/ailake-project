
import { CozeAPI } from '@coze/api';

class CozeSDKIntegration {
  constructor() {
    this.client = null;
    this.isInitialized = false;
    this.config = {
      token: '',
      botId: '',
      baseUrl: 'https://api.coze.com'
    };
  }

  // 初始化COZE客户端
  async initialize(config) {
    try {
      this.config = { ...this.config, ...config };
      
      // 创建COZE API客户端
      this.client = new CozeAPI({
        token: this.config.token,
        baseURL: this.config.baseUrl,
        allowPersonalAccessTokenInBrowser: true
      });
      
      this.isInitialized = true;
      console.log('COZE SDK initialized successfully');
      return { success: true, message: 'COZE智能体已成功初始化！' };
    } catch (error) {
      console.error('Failed to initialize COZE SDK:', error);
      return { success: false, message: '初始化失败: ' + error.message };
    }
  }

  // 发送消息到COZE机器人
  async sendMessage(query, onMessageUpdate) {
    if (!this.isInitialized || !this.client) {
      throw new Error('COZE SDK未初始化');
    }

    try {
      let fullResponse = '';
      
      // 使用流式API发送消息
      const stream = await this.client.chat.stream({
        bot_id: this.config.botId,
        user_id: 'pwa_user_' + Date.now(),
        auto_save_history: true,
        additional_messages: [
          {
            role: 'user',
            content: query,
            content_type: 'text'
          }
        ]
      });

      // 处理流式响应
      for await (const part of stream) {
        if (part.event === 'conversation.message.delta') {
          fullResponse += part.data.content;
          // 实时更新消息
          if (onMessageUpdate) {
            onMessageUpdate(fullResponse);
          }
        }
      }

      return fullResponse;
    } catch (error) {
      console.error('Error sending message:', error);
      throw new Error('发送消息失败: ' + error.message);
    }
  }

  // 清除对话历史
  async clearContext() {
    // 在实际应用中，可能需要调用特定的API来清除上下文
    // 这里我们只是重置状态
    console.log('Context cleared');
  }

  // 检查是否已初始化
  isReady() {
    return this.isInitialized && this.client !== null;
  }
}

// 导出COZE SDK集成类
window.CozeSDKIntegration = CozeSDKIntegration;
