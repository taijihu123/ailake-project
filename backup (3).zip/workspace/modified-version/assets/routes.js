
// 路由配置
const routes = [
  { path: '/login', component: 'LoginPage' },
  { path: '/knowledge-planet', component: 'KnowledgePlanetPage' }
];

// 知识星球页面组件
class KnowledgePlanetPage {
  constructor() {
    this.render();
  }
  
  render() {
    // 仅在知识星球页显示的功能：文档列表、模式切换等
    const app = document.getElementById('root');
    if (app) {
      app.innerHTML = `
        <div>
          <!-- 仅在知识星球页显示的功能：文档列表、模式切换等 -->
          <div class="doc-list">
            <h3>文档列表</h3>
            <ul>
              <li><a href="#">文本解读的个人化认知框架</a></li>
              <li><a href="#">深度学习在自然语言处理中的应用</a></li>
              <li><a href="#">人工智能伦理与社会责任</a></li>
            </ul>
          </div>
          <div class="mode-toggle">
            <h3>模式切换</h3>
            <button id="toggleMode">切换到论文模式</button>
          </div>
        </div>
      `;
    }
  }
}

// 登录页面组件
class LoginPage {
  constructor() {
    this.render();
  }
  
  render() {
    // 仅登录相关内容
    const app = document.getElementById('root');
    if (app) {
      app.innerHTML = `
        <div class="login-container">
          <h2>用户登录</h2>
          <form class="login-form">
            <input type="email" placeholder="邮箱地址" required />
            <input type="password" placeholder="密码" required />
            <button type="submit">登录</button>
          </form>
        </div>
      `;
    }
  }
}

// 路由管理器
class Router {
  constructor() {
    this.routes = routes;
    this.init();
  }
  
  init() {
    // 监听URL变化
    window.addEventListener('hashchange', () => {
      this.route();
    });
    
    // 初始路由
    this.route();
  }
  
  route() {
    const path = window.location.hash.slice(1) || '/knowledge-planet';
    const route = this.routes.find(r => r.path === path);
    
    if (route) {
      // 根据路由组件名称创建对应组件实例
      switch (route.component) {
        case 'KnowledgePlanetPage':
          new KnowledgePlanetPage();
          break;
        case 'LoginPage':
          new LoginPage();
          break;
        default:
          new KnowledgePlanetPage();
      }
    } else {
      // 默认页面
      new KnowledgePlanetPage();
    }
  }
}

// 初始化路由
window.router = new Router();
