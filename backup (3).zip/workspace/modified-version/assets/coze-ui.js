
// COZE智能体UI组件
class CozeUI {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.cozeIntegration = null;
    this.isInitialized = false;
    this.authType = 'pat_token'; // 默认使用PAT令牌
    this.clientId = '60505805192114777123339719601687.app.coze'; // OAuth客户端ID
    this.redirectUrl = 'https://session203e01efb43c4a2281_v1.dakou-hosting.iflow.cn/oauth-callback'; // OAuth重定向URL
    
    if (this.container) {
      this.initUI();
    }
  }

  // 初始化UI
  initUI() {
    this.container.innerHTML = `
      <div id="coze-chat-container" style="display: none;">
        <div id="coze-chat-header" style="background-color: #2D8C5E; color: white; padding: 10px; border-radius: 5px 5px 0 0;">
          <h3 style="margin: 0;">AI助手</h3>
        </div>
        <div id="coze-chat-messages" style="height: 300px; overflow-y: auto; padding: 10px; border: 1px solid #ddd; border-top: none; border-bottom: none; background-color: #f9f9f9;">
          <div id="coze-welcome-message" style="color: #666; font-style: italic;">
            欢迎使用AI助手！请输入您的问题。
          </div>
        </div>
        <div id="coze-chat-input-container" style="border: 1px solid #ddd; border-radius: 0 0 5px 5px; padding: 10px; background-color: white;">
          <div style="display: flex;">
            <input type="text" id="coze-chat-input" placeholder="输入您的问题..." style="flex: 1; padding: 8px; border: 1px solid #ddd; border-radius: 3px; margin-right: 5px;">
            <button id="coze-send-button" style="padding: 8px 15px; background-color: #2D8C5E; color: white; border: none; border-radius: 3px; cursor: pointer;">发送</button>
            <button id="coze-clear-button" style="padding: 8px 10px; background-color: #f44336; color: white; border: none; border-radius: 3px; cursor: pointer; margin-left: 5px;">清除</button>
          </div>
        </div>
      </div>
      
      <div id="coze-setup-container">
        <h3>配置COZE智能体</h3>
        <div style="margin-bottom: 10px;">
          <label for="coze-auth-type">认证方式:</label>
          <select id="coze-auth-type" style="width: 100%; padding: 8px; margin-top: 5px;">
            <option value="pat_token">Personal Access Token</option>
            <option value="oauth">OAuth认证</option>
          </select>
        </div>
        
        <div id="pat-token-container" style="margin-bottom: 10px;">
          <label for="coze-api-token">API令牌:</label>
          <input type="password" id="coze-api-token" placeholder="请输入COZE API令牌" style="width: 100%; padding: 8px; margin-top: 5px;">
        </div>
        
        <div id="oauth-container" style="margin-bottom: 10px; display: none;">
          <p>点击下方按钮进行OAuth认证:</p>
          <button id="coze-oauth-button" style="padding: 10px 15px; background-color: #2D8C5E; color: white; border: none; border-radius: 3px; cursor: pointer;">OAuth认证</button>
        </div>
        
        <div style="margin-bottom: 10px;">
          <label for="coze-bot-id">Bot ID:</label>
          <input type="text" id="coze-bot-id" placeholder="请输入Bot ID" style="width: 100%; padding: 8px; margin-top: 5px;">
        </div>
        <button id="coze-init-button" style="padding: 10px 15px; background-color: #2D8C5E; color: white; border: none; border-radius: 3px; cursor: pointer;">初始化</button>
      </div>
    `;

    this.bindEvents();
  }

  // 绑定事件
  bindEvents() {
    // 认证方式选择事件
    const authTypeSelect = document.getElementById('coze-auth-type');
    if (authTypeSelect) {
      authTypeSelect.addEventListener('change', (e) => {
        this.authType = e.target.value;
        this.toggleAuthFields();
      });
    }
    
    // OAuth按钮事件
    const oauthButton = document.getElementById('coze-oauth-button');
    if (oauthButton) {
      oauthButton.addEventListener('click', () => {
        this.startOAuthFlow();
      });
    }

    // 初始化按钮事件
    const initButton = document.getElementById('coze-init-button');
    if (initButton) {
      initButton.addEventListener('click', () => {
        this.initializeCoze();
      });
    }

    // 发送按钮事件
    const sendButton = document.getElementById('coze-send-button');
    if (sendButton) {
      sendButton.addEventListener('click', () => {
        this.sendMessage();
      });
    }

    // 清除按钮事件
    const clearButton = document.getElementById('coze-clear-button');
    if (clearButton) {
      clearButton.addEventListener('click', () => {
        this.clearContext();
      });
    }

    // 回车发送消息
    const input = document.getElementById('coze-chat-input');
    if (input) {
      input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          this.sendMessage();
        }
      });
    }
  }

  // 切换认证字段显示
  toggleAuthFields() {
    const patContainer = document.getElementById('pat-token-container');
    const oauthContainer = document.getElementById('oauth-container');
    
    if (this.authType === 'pat_token') {
      patContainer.style.display = 'block';
      oauthContainer.style.display = 'none';
    } else {
      patContainer.style.display = 'none';
      oauthContainer.style.display = 'block';
    }
  }

  // 开始OAuth流程
  startOAuthFlow() {
    try {
      // 构造OAuth URL (这里使用Web OAuth方式)
      const oauthUrl = `https://www.coze.com/api/permission/oauth2/web/authorize?client_id=${this.clientId}&redirect_uri=${encodeURIComponent(this.redirectUrl)}&response_type=code&state=coze_pwa_app`;
      
      // 打开新窗口进行OAuth认证
      window.open(oauthUrl, '_blank', 'width=600,height=800');
      
      this.showMessage('请在新打开的窗口中完成OAuth认证，认证完成后请输入Bot ID并点击初始化。', 'success');
    } catch (error) {
      this.showMessage('启动OAuth流程失败: ' + error.message, 'error');
    }
  }

  // 初始化COZE集成
  initializeCoze() {
    const botIdInput = document.getElementById('coze-bot-id');
    const botId = botIdInput.value.trim();
    
    if (!botId) {
      this.showMessage('请提供Bot ID', 'error');
      return;
    }
    
    let config = {
      botId: botId,
      baseUrl: 'https://api.coze.com'
    };
    
    if (this.authType === 'pat_token') {
      const apiTokenInput = document.getElementById('coze-api-token');
      const apiToken = apiTokenInput.value.trim();
      
      if (!apiToken) {
        this.showMessage('请提供API令牌', 'error');
        return;
      }
      
      config.token = apiToken;
    } else {
      // 对于OAuth，我们需要从URL参数或其他方式获取访问令牌
      // 这里我们假设令牌已经通过某种方式获取
      const urlParams = new URLSearchParams(window.location.search);
      const accessToken = urlParams.get('access_token');
      
      if (!accessToken) {
        this.showMessage('OAuth认证未完成，请先完成认证流程', 'error');
        return;
      }
      
      config.token = accessToken;
    }
    
    try {
      // 使用新的SDK集成类
      this.cozeIntegration = new CozeSDKIntegration();
      this.cozeIntegration.initialize(config).then((result) => {
        if (result.success) {
          this.isInitialized = true;
          
          // 隐藏配置界面，显示聊天界面
          document.getElementById('coze-setup-container').style.display = 'none';
          document.getElementById('coze-chat-container').style.display = 'block';
          
          this.showMessage(result.message, 'success');
        } else {
          this.showMessage(result.message, 'error');
        }
      });
    } catch (error) {
      this.showMessage('初始化失败: ' + error.message, 'error');
    }
  }

  // 发送消息
  async sendMessage() {
    if (!this.isInitialized) {
      this.showMessage('请先初始化COZE智能体', 'error');
      return;
    }
    
    const input = document.getElementById('coze-chat-input');
    const message = input.value.trim();
    
    if (!message) {
      return;
    }
    
    // 显示用户消息
    this.displayMessage(message, 'user');
    input.value = '';
    
    try {
      // 显示正在输入的指示器
      const indicator = this.displayMessage('AI正在思考...', 'ai-thinking');
      
      // 使用流式API发送消息
      let fullResponse = '';
      await this.cozeIntegration.sendMessage(message, (partialResponse) => {
        fullResponse = partialResponse;
        // 更新AI回复显示
        if (indicator) {
          indicator.innerHTML = `<strong>AI助手:</strong> ${fullResponse}`;
        }
      });
      
      // 移除正在输入的指示器
      if (indicator && indicator.parentNode) {
        indicator.parentNode.removeChild(indicator);
      }
      
      // 显示完整AI回复
      this.displayMessage(fullResponse, 'ai');
    } catch (error) {
      // 移除正在输入的指示器
      const indicator = document.getElementById('ai-thinking-indicator');
      if (indicator && indicator.parentNode) {
        indicator.parentNode.removeChild(indicator);
      }
      
      this.displayMessage('发送消息时出错: ' + error.message, 'error');
    }
  }

  // 清除上下文
  async clearContext() {
    if (!this.isInitialized) {
      this.showMessage('请先初始化COZE智能体', 'error');
      return;
    }
    
    try {
      await this.cozeIntegration.clearContext();
      // 清空聊天记录
      const messagesContainer = document.getElementById('coze-chat-messages');
      messagesContainer.innerHTML = '<div id="coze-welcome-message" style="color: #666; font-style: italic;">上下文已清除。欢迎使用AI助手！请输入您的问题。</div>';
      this.showMessage('上下文已清除', 'success');
    } catch (error) {
      this.showMessage('清除上下文时出错: ' + error.message, 'error');
    }
  }

  // 显示消息
  displayMessage(content, type) {
    const messagesContainer = document.getElementById('coze-chat-messages');
    const welcomeMessage = document.getElementById('coze-welcome-message');
    
    // 如果有欢迎消息，先移除它
    if (welcomeMessage) {
      messagesContainer.removeChild(welcomeMessage);
    }
    
    const messageDiv = document.createElement('div');
    messageDiv.style.marginBottom = '10px';
    messageDiv.style.padding = '8px';
    messageDiv.style.borderRadius = '5px';
    messageDiv.style.wordWrap = 'break-word';
    
    if (type === 'user') {
      messageDiv.style.backgroundColor = '#DCF8C6';
      messageDiv.style.textAlign = 'right';
      messageDiv.innerHTML = `<strong>您:</strong> ${content}`;
    } else if (type === 'ai') {
      messageDiv.style.backgroundColor = '#E5E5EA';
      messageDiv.style.textAlign = 'left';
      messageDiv.innerHTML = `<strong>AI助手:</strong> ${content}`;
    } else if (type === 'ai-thinking') {
      messageDiv.style.backgroundColor = '#E5E5EA';
      messageDiv.style.textAlign = 'left';
      messageDiv.innerHTML = `<strong>AI助手:</strong> <em>${content}</em>`;
      messageDiv.id = 'ai-thinking-indicator';
    } else if (type === 'success') {
      messageDiv.style.backgroundColor = '#D4EDDA';
      messageDiv.style.color = '#155724';
      messageDiv.innerHTML = content;
    } else if (type === 'error') {
      messageDiv.style.backgroundColor = '#F8D7DA';
      messageDiv.style.color = '#721C24';
      messageDiv.innerHTML = content;
    }
    
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    return messageDiv;
  }

  // 显示通知消息
  showMessage(content, type = 'info') {
    const messagesContainer = document.getElementById('coze-chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.style.marginBottom = '10px';
    messageDiv.style.padding = '8px';
    messageDiv.style.borderRadius = '5px';
    messageDiv.style.wordWrap = 'break-word';
    
    if (type === 'success') {
      messageDiv.style.backgroundColor = '#D4EDDA';
      messageDiv.style.color = '#155724';
    } else if (type === 'error') {
      messageDiv.style.backgroundColor = '#F8D7DA';
      messageDiv.style.color = '#721C24';
    } else {
      messageDiv.style.backgroundColor = '#D1ECF1';
      messageDiv.style.color = '#0C5460';
    }
    
    messageDiv.innerHTML = content;
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }
}

// 初始化COZE UI组件
window.CozeUI = CozeUI;
