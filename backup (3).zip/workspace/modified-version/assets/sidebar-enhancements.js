
// 侧边栏增强功能
class SidebarEnhancements {
  constructor() {
    this.isPaperMode = false;
    this.init();
  }

  init() {
    // 等待DOM加载完成
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.setupUI());
    } else {
      this.setupUI();
    }
  }

  setupUI() {
    // 创建侧边栏功能区域
    this.createSidebarFuncArea();
    
    // 创建底部论文模式按钮
    this.createPaperModeButton();
    
    // 创建个人中心菜单
    this.createUserMenu();
    
    // 绑定事件
    this.bindEvents();
  }

  createSidebarFuncArea() {
    // 在页面上创建侧边栏功能区域
    const sidebarTop = document.createElement('div');
    sidebarTop.className = 'sidebar-top';
    sidebarTop.innerHTML = `
      <button class="toggle-func-btn" style="background: #2D8C5E; color: white; border: none; border-radius: 50%; width: 30px; height: 30px; cursor: pointer; margin: 10px;">⚙️</button>
    `;
    
    // 创建侧边栏功能区域（默认隐藏）
    const sidebarFuncArea = document.createElement('div');
    sidebarFuncArea.className = 'sidebar-func-area';
    sidebarFuncArea.id = 'sidebarFuncArea';
    sidebarFuncArea.style.display = 'none';
    sidebarFuncArea.style.padding = '10px';
    sidebarFuncArea.innerHTML = `
      <button onclick="sidebarEnhancements.showMemberRights()" style="display: block; width: 100%; padding: 10px; margin: 5px 0; background: #f0f0f0; border: none; border-radius: 5px; cursor: pointer;">会员权益</button>
      <button onclick="sidebarEnhancements.submitPaper()" style="display: block; width: 100%; padding: 10px; margin: 5px 0; background: #f0f0f0; border: none; border-radius: 5px; cursor: pointer;">提交论文</button>
    `;
    
    // 将元素添加到页面上
    document.body.appendChild(sidebarTop);
    document.body.appendChild(sidebarFuncArea);
  }

  createPaperModeButton() {
    // 创建论文模式按钮
    const paperModeBtn = document.createElement('button');
    paperModeBtn.className = 'paper-mode-btn';
    paperModeBtn.id = 'paperModeBtn';
    paperModeBtn.textContent = '论文模式';
    paperModeBtn.style.position = 'fixed';
    paperModeBtn.style.bottom = '70px';
    paperModeBtn.style.right = '20px';
    paperModeBtn.style.padding = '10px 20px';
    paperModeBtn.style.backgroundColor = '#2D8C5E';
    paperModeBtn.style.color = 'white';
    paperModeBtn.style.border = 'none';
    paperModeBtn.style.borderRadius = '5px';
    paperModeBtn.style.cursor = 'pointer';
    paperModeBtn.style.zIndex = '9999';
    
    document.body.appendChild(paperModeBtn);
  }

  createUserMenu() {
    // 创建个人中心菜单
    const userMenu = document.createElement('div');
    userMenu.className = 'user-menu';
    userMenu.id = 'userMenu';
    userMenu.style.position = 'fixed';
    userMenu.style.bottom = '120px';
    userMenu.style.right = '20px';
    userMenu.style.backgroundColor = 'white';
    userMenu.style.border = '1px solid #ddd';
    userMenu.style.borderRadius = '5px';
    userMenu.style.padding = '10px';
    userMenu.style.display = 'none';
    userMenu.style.zIndex = '10000';
    userMenu.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
    userMenu.innerHTML = `
      <div class="menu-item" onclick="sidebarEnhancements.showMemberRights()" style="padding: 10px; cursor: pointer; border-bottom: 1px solid #eee;">会员权益</div>
      <div class="menu-item" onclick="sidebarEnhancements.showAccountInfo()" style="padding: 10px; cursor: pointer;">账户信息</div>
    `;
    
    document.body.appendChild(userMenu);
  }

  bindEvents() {
    // 绑定侧边栏功能按钮事件
    const toggleBtn = document.querySelector('.toggle-func-btn');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', () => this.toggleSidebarFunc());
    }
    
    // 绑定论文模式按钮事件
    const paperModeBtn = document.getElementById('paperModeBtn');
    if (paperModeBtn) {
      paperModeBtn.addEventListener('click', () => this.togglePaperMode());
    }
    
    // 模拟用户中心按钮（在页面底部添加一个按钮来触发菜单）
    const userCenterBtn = document.createElement('button');
    userCenterBtn.innerHTML = '⋮';
    userCenterBtn.style.position = 'fixed';
    userCenterBtn.style.bottom = '20px';
    userCenterBtn.style.right = '20px';
    userCenterBtn.style.padding = '10px 15px';
    userCenterBtn.style.backgroundColor = '#2D8C5E';
    userCenterBtn.style.color = 'white';
    userCenterBtn.style.border = 'none';
    userCenterBtn.style.borderRadius = '5px';
    userCenterBtn.style.cursor = 'pointer';
    userCenterBtn.style.zIndex = '9999';
    userCenterBtn.title = '个人中心';
    
    userCenterBtn.addEventListener('click', () => this.toggleUserMenu());
    document.body.appendChild(userCenterBtn);
  }

  toggleSidebarFunc() {
    const funcArea = document.getElementById('sidebarFuncArea');
    if (funcArea) {
      funcArea.style.display = funcArea.style.display === 'block' ? 'none' : 'block';
    }
  }

  togglePaperMode() {
    this.isPaperMode = !this.isPaperMode;
    const btn = document.getElementById('paperModeBtn');
    if (btn) {
      btn.textContent = this.isPaperMode ? '退出论文模式' : '论文模式';
      btn.style.backgroundColor = this.isPaperMode ? '#1a5c3f' : '#2D8C5E';
    }
    
    // 显示提示信息
    this.showNotification('已切换为论文模式，AI 将更聚焦学术内容生成～');
  }

  toggleUserMenu() {
    const menu = document.getElementById('userMenu');
    if (menu) {
      menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
    }
  }

  showMemberRights() {
    // 显示会员权益信息
    this.showNotification('会员权益功能正在开发中...');
    this.hideMenus();
  }

  submitPaper() {
    // 显示论文提交功能
    this.showNotification('论文提交功能正在开发中...');
    this.hideMenus();
  }

  showAccountInfo() {
    // 显示账户信息
    this.showNotification('账户信息功能正在开发中...');
    this.hideMenus();
  }

  hideMenus() {
    // 隐藏所有菜单
    const funcArea = document.getElementById('sidebarFuncArea');
    const userMenu = document.getElementById('userMenu');
    
    if (funcArea) funcArea.style.display = 'none';
    if (userMenu) userMenu.style.display = 'none';
  }

  showNotification(message) {
    // 显示通知信息
    const notification = document.createElement('div');
    notification.textContent = message;
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.padding = '15px 20px';
    notification.style.backgroundColor = '#2D8C5E';
    notification.style.color = 'white';
    notification.style.borderRadius = '5px';
    notification.style.zIndex = '10001';
    notification.style.boxShadow = '0 2px 10px rgba(0,0,0,0.2)';
    
    document.body.appendChild(notification);
    
    // 3秒后自动消失
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 3000);
  }
}

// 初始化侧边栏增强功能
const sidebarEnhancements = new SidebarEnhancements();

// 将函数暴露到全局作用域
window.sidebarEnhancements = sidebarEnhancements;
window.toggleSidebarFunc = () => sidebarEnhancements.toggleSidebarFunc();
window.togglePaperMode = () => sidebarEnhancements.togglePaperMode();
window.showMemberRights = () => sidebarEnhancements.showMemberRights();
window.submitPaper = () => sidebarEnhancements.submitPaper();
window.showAccountInfo = () => sidebarEnhancements.showAccountInfo();
