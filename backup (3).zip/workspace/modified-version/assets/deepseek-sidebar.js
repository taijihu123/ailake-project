
// DeepSeek 风格侧边栏交互逻辑
class DeepSeekSidebar {
  constructor() {
    this.init();
  }

  init() {
    // 等待DOM加载完成
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.setupUI());
    } else {
      this.setupUI();
    }
  }

  setupUI() {
    // 页面加载时，判断当前页面类型
    const currentPath = window.location.pathname;
    const pageTitle = document.title.toLowerCase();
    
    // 知识星球页面
    if (currentPath === "/knowledge-planet" || currentPath === "/知识星球" || pageTitle.includes("知识星球") || pageTitle.includes("星球")) {
      this.initKnowledgePlanetFeatures();
    } 
    // 对话页面
    else if (currentPath === "/chat" || currentPath === "/对话" || pageTitle.includes("对话") || pageTitle.includes("chat")) {
      this.initChatFeatures();
    } 
    // 登录页面
    else if (currentPath === "/login" || currentPath === "/登录" || pageTitle.includes("登录") || pageTitle.includes("login")) {
      this.initLoginFeatures();
    } 
    // 默认页面
    else {
      this.initDefaultFeatures();
    }
  }

  initChatFeatures() {
    // 为对话页面创建专门的布局
    this.createTopBar();
    this.createSidebar();
    this.createMainContent();
    this.removeOldButtons();
    this.bindEvents();
    
    // 添加对话特定的样式
    this.addChatStyles();
  }

  initLoginFeatures() {
    // 为登录页面创建简洁的布局，不包含侧边栏
    this.createMainContent();
    this.removeOldButtons();
    this.removeSidebar(); // 确保移除侧边栏和左上角的三条线按钮
    
    // 添加登录特定的样式
    this.addLoginStyles();
    
    // 确保顶部栏也被移除
    this.removeTopBar();
  }

  removeTopBar() {
    // 移除顶部栏元素
    const topBar = document.querySelector('.top-bar');
    if (topBar) {
      topBar.remove();
    }
  }

  initDefaultFeatures() {
    // 默认页面使用知识星球的布局
    this.initKnowledgePlanetFeatures();
  }

  initKnowledgePlanetFeatures() {
    // 创建顶部栏（包含侧边栏切换按钮）
    this.createTopBar();
    
    // 创建侧边栏
    this.createSidebar();
    
    // 创建主内容区（如果不存在）
    this.createMainContent();
    
    // 移除旧的按钮
    this.removeOldButtons();
    
    // 绑定事件
    this.bindEvents();
  }

  removeSidebar() {
    // 移除侧边栏元素
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
      sidebar.remove();
    }
    
    // 移除侧边栏切换按钮
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    if (sidebarToggle) {
      sidebarToggle.remove();
    }
  }

  addChatStyles() {
    // 为对话页面添加特定样式
    const style = document.createElement('style');
    style.textContent = `
      .chat-container {
        display: flex;
        flex-direction: column;
        height: calc(100vh - 100px);
        margin: 20px;
        border: 1px solid #ddd;
        border-radius: 5px;
        overflow: hidden;
      }
      
      .chat-messages {
        flex: 1;
        overflow-y: auto;
        padding: 20px;
        background-color: #f9f9f9;
      }
      
      .chat-input {
        display: flex;
        padding: 20px;
        background-color: #fff;
        border-top: 1px solid #eee;
      }
      
      .chat-input input {
        flex: 1;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        margin-right: 10px;
      }
      
      .chat-input button {
        padding: 10px 20px;
        background-color: #2D8C5E;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
      }
    `;
    document.head.appendChild(style);
  }

  addLoginStyles() {
    // 为登录页面添加特定样式
    const style = document.createElement('style');
    style.textContent = `
      .login-container {
        max-width: 400px;
        margin: 100px auto;
        padding: 40px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        text-align: center;
      }
      
      .login-form {
        margin-top: 30px;
      }
      
      .login-form input {
        width: 100%;
        padding: 12px;
        margin: 10px 0;
        border: 1px solid #ddd;
        border-radius: 4px;
        box-sizing: border-box;
      }
      
      .login-form button {
        width: 100%;
        padding: 12px;
        background-color: #2D8C5E;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
        margin-top: 20px;
      }
      
      .login-form button:hover {
        background-color: #257550;
      }
    `;
    document.head.appendChild(style);
  }

  initKnowledgePlanetFeatures() {
    // 创建顶部栏
    this.createTopBar();
    
    // 创建侧边栏
    this.createSidebar();
    
    // 创建主内容区（如果不存在）
    this.createMainContent();
    
    // 移除旧的按钮
    this.removeOldButtons();
    
    // 绑定事件
    this.bindEvents();
  }

  createTopBar() {
    // 检查是否已存在顶部栏
    if (document.querySelector('.top-bar')) {
      return;
    }
    
    // 创建顶部栏
    const topBar = document.createElement('header');
    topBar.className = 'top-bar';
    topBar.innerHTML = `
      <button class="sidebar-toggle" id="sidebarToggle">☰</button>
      <img src="/assets/ai-avatar.jpg" alt="AI Avatar" style="width: 30px; height: 30px; margin-right: 10px; border-radius: 50%;">
    `;
    
    // 将顶部栏添加到页面开头
    document.body.insertBefore(topBar, document.body.firstChild);
  }

  createSidebar() {
    // 检查是否已存在侧边栏
    if (document.getElementById('sidebar')) {
      return;
    }
    
    // 创建侧边栏
    const sidebar = document.createElement('aside');
    sidebar.className = 'sidebar';
    sidebar.id = 'sidebar';
    sidebar.innerHTML = `
      <!-- 侧边栏内容：文档列表 + 功能入口 -->
      <div class="doc-list">
        <h3>文档列表</h3>
        <ul>
          <li><a href="#">文本解读的个人化认知框架</a></li>
          <li><a href="#">深度学习在自然语言处理中的应用</a></li>
          <li><a href="#">人工智能伦理与社会责任</a></li>
        </ul>
      </div>
      <div class="func-entries">
        <h3>功能入口</h3>
        <ul>
          <li><a href="#" onclick="showMemberRights()">会员权益</a></li>
          <li><a href="#" onclick="submitPaper()">提交论文</a></li>
          <li><a href="#" onclick="showAccountInfo()">账户设置</a></li>
        </ul>
      </div>
    `;
    
    // 将侧边栏添加到页面
    document.body.appendChild(sidebar);
  }

  createMainContent() {
    // 检查是否已存在主内容区
    if (document.querySelector('.main-content')) {
      return;
    }
    
    // 获取现有的内容容器
    const root = document.getElementById('root');
    const cozeContainer = document.getElementById('coze-container');
    const initCozeBtn = document.getElementById('init-coze-btn');
    
    // 创建主内容区
    const mainContent = document.createElement('main');
    mainContent.className = 'main-content';
    
    // 将现有内容移动到主内容区
    if (root) {
      mainContent.appendChild(root);
    }
    
    if (cozeContainer) {
      mainContent.appendChild(cozeContainer);
    }
    
    if (initCozeBtn) {
      mainContent.appendChild(initCozeBtn);
    }
    
    // 将主内容区添加到页面
    document.body.appendChild(mainContent);
  }

  removeOldButtons() {
    // 移除旧的按钮
    const oldButtons = document.querySelectorAll('.toggle-func-btn, .paper-mode-btn, .user-more-btn, .user-menu, #paperModeBtn');
    oldButtons.forEach(button => {
      if (button.parentNode) {
        button.parentNode.removeChild(button);
      }
    });
  }

  bindEvents() {
    // 绑定侧边栏切换事件
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    
    if (sidebarToggle && sidebar) {
      sidebarToggle.addEventListener('click', () => {
        sidebar.classList.toggle('open');
      });
      
      // 点击主内容区，可关闭侧边栏（可选）
      const mainContent = document.querySelector('.main-content');
      if (mainContent) {
        mainContent.addEventListener('click', (event) => {
          // 检查点击的元素是否在侧边栏内
          if (!sidebar.contains(event.target) && sidebar.classList.contains('open')) {
            sidebar.classList.remove('open');
          }
        });
      }
    }
  }
}

// 初始化DeepSeek风格侧边栏
const deepSeekSidebar = new DeepSeekSidebar();

// 将函数暴露到全局作用域
window.deepSeekSidebar = deepSeekSidebar;
window.showMemberRights = () => {
  alert('会员权益功能正在开发中...');
  // 关闭侧边栏
  const sidebar = document.getElementById('sidebar');
  if (sidebar) {
    sidebar.classList.remove('open');
  }
};
window.submitPaper = () => {
  alert('提交论文功能正在开发中...');
  // 关闭侧边栏
  const sidebar = document.getElementById('sidebar');
  if (sidebar) {
    sidebar.classList.remove('open');
  }
};
window.showAccountInfo = () => {
  alert('账户设置功能正在开发中...');
  // 关闭侧边栏
  const sidebar = document.getElementById('sidebar');
  if (sidebar) {
    sidebar.classList.remove('open');
  }
};
