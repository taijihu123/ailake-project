import { useState } from 'react'
import { Header } from './components/Header'
import { cozeIntegration } from './integrations/coze'

function App() {
  const [message, setMessage] = useState('')
  const [response, setResponse] = useState('')

  const handleSendMessage = () => {
    if (message.trim() === '') return
  
    // 使用COZE集成发送消息
    cozeIntegration.sendMessage(message)
    
    // 模拟响应
    setResponse(`已发送消息: "${message}" 到COZE智能体`)
    setMessage('')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">COZE智能体集成演示</h1>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">发送消息到COZE智能体</h2>
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="输入消息..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            />
            <button
              onClick={handleSendMessage}
              className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              发送
            </button>
          </div>
          
          {response && (
            <div className="mt-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-md">
              {response}
            </div>
          )}
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">DeepSeek风格侧边栏</h2>
          <p>这是一个演示页面，展示了COZE智能体集成和DeepSeek风格侧边栏的功能。</p>
        </div>
      </div>
    </div>
  )
}

export default App
