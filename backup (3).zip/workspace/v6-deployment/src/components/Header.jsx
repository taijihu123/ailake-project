import React from 'react';

export const Header = () => (
  <header className="bg-blue-600 text-white p-4 shadow-md">
    <div className="container mx-auto flex justify-between items-center">
      <h1 className="text-xl font-bold">DeepSeek风格侧边栏</h1>
      <nav>
        <ul className="flex space-x-4">
          <li><a href="#" className="hover:text-blue-200">首页</a></li>
          <li><a href="#" className="hover:text-blue-200">文档</a></li>
          <li><a href="#" className="hover:text-blue-200">功能</a></li>
          <li><a href="#" className="hover:text-blue-200">设置</a></li>
        </ul>
      </nav>
    </div>
  </header>
);
