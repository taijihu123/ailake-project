export const cozeIntegration: {
  init: () => void;
  sendMessage: (msg: string) => void;
};
