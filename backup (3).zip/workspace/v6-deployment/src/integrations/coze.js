/* COZE智能体集成 */
export const cozeIntegration = {
  init: () => console.log('COZE agent initialized'),
  sendMessage: (msg) => console.log('Sending message to COZE:', msg)
};
